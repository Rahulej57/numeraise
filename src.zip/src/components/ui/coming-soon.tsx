import Link from "next/link";
import { Wrench, ArrowLeft, Construction } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";

interface ComingSoonProps {
  title: string;
  description?: string;
}

export function ComingSoon({ title, description }: ComingSoonProps) {
  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center text-center px-4">
      <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mb-8 relative">
        <Construction className="w-12 h-12 text-primary" />
        <div className="absolute -bottom-2 -right-2 w-10 h-10 bg-background rounded-full flex items-center justify-center border-4 border-muted">
          <Wrench className="w-5 h-5 text-muted-foreground animate-pulse" />
        </div>
      </div>
      
      <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-4">
        {title} <span className="text-primary bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/60">Coming Soon</span>
      </h1>
      
      <p className="text-lg text-muted-foreground max-w-xl mx-auto mb-10 leading-relaxed">
        {description || "Our engineers and financial experts are actively building this feature. We're crafting the perfect tool to help you make smarter financial decisions."}
      </p>
      
      <div className="flex flex-col sm:flex-row gap-4">
        <Link href="/" className={buttonVariants({ size: "lg" })}>
          <ArrowLeft className="w-4 h-4 mr-2" /> Return Home
        </Link>
        <Link href="/calculators" className={buttonVariants({ variant: "outline", size: "lg" })}>
          Explore Available Tools
        </Link>
      </div>
    </div>
  );
}
