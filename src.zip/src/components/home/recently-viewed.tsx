"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { History, ArrowRight } from "lucide-react";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";

interface ViewedCalculator {
  title: string;
  href: string;
}

export function RecentlyViewed() {
  const [recentlyViewed, setRecentlyViewed] = useState<ViewedCalculator[]>([]);

  useEffect(() => {
    // In a real implementation, each calculator page would push to this localStorage array
    // For demonstration, we will attempt to parse it, or fallback to an empty array
    try {
      const stored = localStorage.getItem("fincalcpro_recently_viewed");
      if (stored) {
        setRecentlyViewed(JSON.parse(stored).slice(0, 4));
      } else {
        // Mock data if none exists so the user sees the feature working
        setRecentlyViewed([
          { title: "SIP Calculator", href: "/calculators/sip-calculator" },
          { title: "EMI Calculator", href: "/calculators/emi-calculator" }
        ]);
      }
    } catch (e) {
      console.error("Failed to parse recently viewed calculators");
    }
  }, []);

  if (recentlyViewed.length === 0) return null;

  return (
    <section className="w-full py-10 bg-background border-t border-border">
      <div className="container mx-auto px-4 max-w-5xl">
        <div className="flex items-center gap-2 mb-6">
          <History className="w-5 h-5 text-muted-foreground" />
          <h3 className="text-xl font-bold tracking-tight">Recently Viewed by You</h3>
        </div>
        
        <div className="flex flex-wrap gap-4">
          {recentlyViewed.map((calc, idx) => (
            <Link href={calc.href} key={idx}>
              <Card className="hover:border-primary/50 transition-colors bg-muted/30">
                <CardHeader className="py-3 px-4 flex flex-row items-center gap-4 space-y-0">
                  <CardTitle className="text-sm font-medium">{calc.title}</CardTitle>
                  <ArrowRight className="w-4 h-4 text-muted-foreground" />
                </CardHeader>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
