import Link from "next/link";
import { BookOpen, ArrowRight } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export function FeaturedArticles() {
  const articles = [
    {
      title: "SIP vs Fixed Deposit: Where should you invest?",
      description: "A comprehensive guide on evaluating risk and reward between market-linked SIPs and secure bank FDs.",
      href: "/articles/sip-vs-fd",
      category: "Investing",
    },
    {
      title: "The Power of Compound Interest",
      description: "How compounding works and why starting your investments early is the key to building generational wealth.",
      href: "/articles/compound-interest-guide",
      category: "Wealth Building",
    },
    {
      title: "Step-by-Step Retirement Planning",
      description: "Calculate your retirement corpus and learn how to allocate assets to beat inflation after you stop working.",
      href: "/articles/retirement-planning",
      category: "Retirement",
    },
    {
      title: "Maximizing Home Loan Tax Benefits",
      description: "Everything you need to know about Section 80C, Section 24b, and claiming deductions on your mortgage.",
      href: "/articles/home-loan-tax-benefits",
      category: "Taxes",
    },
  ];

  return (
    <section className="w-full py-20 bg-background">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="flex flex-col md:flex-row items-end justify-between mb-12 gap-4">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 mb-4">
              <BookOpen className="w-6 h-6 text-primary" />
              <h2 className="text-3xl font-bold tracking-tight">Financial Learning Center</h2>
            </div>
            <p className="text-muted-foreground text-lg">
              Master your personal finances with our comprehensive guides, completely free.
            </p>
          </div>
          <Link href="/articles" className="text-primary hover:underline font-medium whitespace-nowrap flex items-center gap-1">
            Read all articles <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {articles.map((article, idx) => (
            <Link href={article.href} key={idx} className="group">
              <Card className="h-full hover:border-primary/40 transition-colors">
                <CardHeader>
                  <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                    {article.category}
                  </span>
                  <CardTitle className="text-xl mb-2 group-hover:text-primary transition-colors">
                    {article.title}
                  </CardTitle>
                  <CardDescription className="text-base line-clamp-2">
                    {article.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
