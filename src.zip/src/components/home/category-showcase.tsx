import Link from "next/link";
import { TrendingUp, Landmark, PiggyBank, ReceiptText, ShieldAlert, HeartHandshake, ArrowRight } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

const CATEGORIES = [
  {
    title: "Investments",
    description: "Grow your wealth with mutual funds, SIPs, and stocks.",
    icon: <TrendingUp className="w-8 h-8" />,
    count: 12,
    href: "/calculators/category/investments",
    color: "text-emerald-500",
    bg: "bg-emerald-500/10",
  },
  {
    title: "Loans",
    description: "Plan your borrowing for homes, cars, and education.",
    icon: <Landmark className="w-8 h-8" />,
    count: 8,
    href: "/calculators/category/loans",
    color: "text-blue-500",
    bg: "bg-blue-500/10",
  },
  {
    title: "Savings",
    description: "Calculate secure returns from FDs, RDs, and PPF.",
    icon: <PiggyBank className="w-8 h-8" />,
    count: 15,
    href: "/calculators/category/savings",
    color: "text-amber-500",
    bg: "bg-amber-500/10",
  },
  {
    title: "Taxes",
    description: "Optimize your income tax and GST liabilities.",
    icon: <ReceiptText className="w-8 h-8" />,
    count: 5,
    href: "/calculators/category/taxes",
    color: "text-rose-500",
    bg: "bg-rose-500/10",
  },
  {
    title: "Insurance",
    description: "Determine your term life and health cover needs.",
    icon: <ShieldAlert className="w-8 h-8" />,
    count: 4,
    href: "/calculators/category/insurance",
    color: "text-indigo-500",
    bg: "bg-indigo-500/10",
  },
  {
    title: "Retirement",
    description: "Build a corpus for your golden years and FIRE.",
    icon: <HeartHandshake className="w-8 h-8" />,
    count: 6,
    href: "/calculators/category/retirement",
    color: "text-purple-500",
    bg: "bg-purple-500/10",
  },
];

export function CategoryShowcase() {
  return (
    <section className="w-full py-16 bg-muted/20">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <h2 className="text-3xl font-bold tracking-tight mb-4">Browse by Category</h2>
          <p className="text-muted-foreground text-lg">
            Find the exact financial tool you need from our comprehensive categories.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {CATEGORIES.map((cat) => (
            <Link href={cat.href} key={cat.title} className="group">
              <Card className="h-full hover:border-primary/50 hover:shadow-md transition-all duration-300">
                <CardHeader className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className={`p-3 rounded-2xl ${cat.bg} ${cat.color} group-hover:scale-110 transition-transform duration-300`}>
                      {cat.icon}
                    </div>
                    <span className="text-xs font-semibold bg-muted px-2.5 py-1 rounded-full text-muted-foreground">
                      {cat.count} Tools
                    </span>
                  </div>
                  <CardTitle className="text-xl mb-2 group-hover:text-primary transition-colors">
                    {cat.title}
                  </CardTitle>
                  <CardDescription className="text-base">
                    {cat.description}
                  </CardDescription>
                  <div className="mt-6 flex items-center text-sm font-medium text-primary opacity-0 group-hover:opacity-100 transition-opacity -translate-x-2 group-hover:translate-x-0 duration-300">
                    Explore Category <ArrowRight className="w-4 h-4 ml-1" />
                  </div>
                </CardHeader>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
