import Link from "next/link";
import { ArrowRightLeft } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

const COMPARISONS = [
  {
    title: "SIP vs Lumpsum",
    description: "Which investment strategy generates more wealth in the long run?",
    href: "/compare/sip-vs-lumpsum",
  },
  {
    title: "SIP vs Fixed Deposit",
    description: "Compare mutual fund market returns against secure bank deposits.",
    href: "/compare/sip-vs-fd",
  },
  {
    title: "15 Year vs 20 Year Home Loan",
    description: "See how reducing your tenure by 5 years saves lakhs in interest.",
    href: "/compare/home-loan-tenure",
  },
  {
    title: "Prepayment Impact Calculator",
    description: "Calculate how paying an extra EMI per year affects your loan.",
    href: "/calculators/home-loan-prepayment",
  },
];

export function FeaturedComparison() {
  return (
    <section className="w-full py-16 bg-primary/5 dark:bg-primary/10 border-y border-border">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center text-center max-w-2xl mx-auto mb-12">
          <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-primary mb-4">
            <ArrowRightLeft className="w-6 h-6" />
          </div>
          <h2 className="text-3xl font-bold tracking-tight mb-4">Compare Financial Scenarios</h2>
          <p className="text-muted-foreground text-lg">
            Make data-driven decisions by comparing two different financial strategies side-by-side.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {COMPARISONS.map((comp, idx) => (
            <Link href={comp.href} key={idx} className="group">
              <Card className="h-full bg-background/50 backdrop-blur-sm hover:bg-background hover:border-primary/50 transition-all">
                <CardHeader>
                  <CardTitle className="text-lg mb-2 group-hover:text-primary transition-colors">
                    {comp.title}
                  </CardTitle>
                  <CardDescription>
                    {comp.description}
                  </CardDescription>
                </CardHeader>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
