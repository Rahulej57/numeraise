import Link from "next/link";
import { HelpCircle } from "lucide-react";

export function GlossaryPreview() {
  const terms = [
    { term: "SIP", href: "/glossary/sip" },
    { term: "CAGR", href: "/glossary/cagr" },
    { term: "XIRR", href: "/glossary/xirr" },
    { term: "Inflation", href: "/glossary/inflation" },
    { term: "Asset Allocation", href: "/glossary/asset-allocation" },
    { term: "Compounding", href: "/glossary/compounding" },
    { term: "Amortization", href: "/glossary/amortization" },
    { term: "Repo Rate", href: "/glossary/repo-rate" },
  ];

  return (
    <section className="w-full py-16 bg-muted/30 border-y border-border">
      <div className="container mx-auto px-4 max-w-5xl text-center">
        <HelpCircle className="w-8 h-8 text-muted-foreground mx-auto mb-4" />
        <h2 className="text-2xl font-bold tracking-tight mb-8">Financial Glossary</h2>
        
        <div className="flex flex-wrap justify-center gap-3">
          {terms.map((t, idx) => (
            <Link 
              key={idx} 
              href={t.href}
              className="px-4 py-2 bg-background border border-border rounded-full text-sm font-medium hover:border-primary hover:text-primary transition-colors"
            >
              What is {t.term}?
            </Link>
          ))}
          <Link 
            href="/glossary"
            className="px-4 py-2 bg-primary/10 text-primary border border-transparent rounded-full text-sm font-medium hover:bg-primary/20 transition-colors"
          >
            View Entire Glossary &rarr;
          </Link>
        </div>
      </div>
    </section>
  );
}
