import { CheckCircle2 } from "lucide-react";

export function WhyChooseUs() {
  const benefits = [
    { title: "Accurate Financial Calculations", description: "Formulas identical to top-tier financial banks." },
    { title: "Regularly Updated Rules", description: "Tax slabs and FD rates updated dynamically." },
    { title: "Blazing Fast Results", description: "Instant calculations with zero server lag." },
    { title: "Mobile Friendly", description: "Perfectly responsive on all devices and screen sizes." },
    { title: "Privacy Focused", description: "Your financial data never leaves your browser." },
    { title: "No Signup Required", description: "100% free access without email walls." },
  ];

  return (
    <section className="w-full py-20 bg-background">
      <div className="container mx-auto px-4 max-w-5xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Why Choose FinCalcPro?</h2>
          <p className="text-lg text-muted-foreground">We build professional-grade tools for everyday investors.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, idx) => (
            <div key={idx} className="flex gap-4 p-4 rounded-xl hover:bg-muted/50 transition-colors">
              <CheckCircle2 className="w-8 h-8 text-primary shrink-0" />
              <div>
                <h3 className="font-bold text-lg mb-1">{benefit.title}</h3>
                <p className="text-muted-foreground text-sm">{benefit.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
