import Link from "next/link";
import { Flame } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export function TrendingCalculators() {
  const trending = [
    { title: "Income Tax Calculator", metric: "Most Used This Week", href: "/calculators/income-tax-calculator" },
    { title: "SIP Calculator", metric: "Most Calculated", href: "/calculators/sip-calculator" },
    { title: "GST Calculator", metric: "Fastest Growing", href: "/calculators/gst-calculator" },
    { title: "Home Loan EMI", metric: "Popular Category", href: "/calculators/home-loan-calculator" },
  ];

  return (
    <section className="w-full py-16 bg-muted/10">
      <div className="container mx-auto px-4">
        <div className="flex items-center gap-2 mb-8 max-w-5xl mx-auto">
          <Flame className="w-6 h-6 text-orange-500 animate-pulse" />
          <h2 className="text-2xl font-bold tracking-tight">Trending Right Now</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 max-w-5xl mx-auto">
          {trending.map((item, idx) => (
            <Link href={item.href} key={idx} className="group">
              <Card className="h-full hover:border-orange-500/50 hover:shadow-md transition-all duration-300 bg-background/50 backdrop-blur">
                <CardHeader className="p-5">
                  <span className="text-xs font-semibold text-orange-500 uppercase tracking-wider mb-2 block">
                    {item.metric}
                  </span>
                  <CardTitle className="text-base group-hover:text-primary transition-colors">
                    {item.title}
                  </CardTitle>
                </CardHeader>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
