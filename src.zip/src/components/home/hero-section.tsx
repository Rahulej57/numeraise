"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { buttonVariants } from "@/components/ui/button";
import { CheckCircle2, ChevronRight } from "lucide-react";
import { SliderInput } from "@/components/calculators/slider-input";
import { calculateSIP } from "@/lib/calculations/investment";

export function HeroSection() {
  const [monthlyInvestment, setMonthlyInvestment] = useState(5000);
  const [expectedReturnRate, setExpectedReturnRate] = useState(12);
  const [timePeriodYears, setTimePeriodYears] = useState(15);

  const result = useMemo(
    () => calculateSIP(monthlyInvestment, expectedReturnRate, timePeriodYears),
    [monthlyInvestment, expectedReturnRate, timePeriodYears]
  );

  return (
    <section className="relative overflow-hidden w-full py-12 md:py-20 lg:py-28 bg-muted/20 border-b">
      <div className="absolute inset-0 bg-grid-white/5 bg-[size:32px_32px] [mask-image:linear-gradient(to_bottom,white,transparent)] dark:bg-grid-white/5 dark:[mask-image:linear-gradient(to_bottom,white,transparent)]" />
      
      <div className="container relative mx-auto px-4 z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
          
          {/* Left Side: Copy */}
          <div className="flex flex-col space-y-8 text-center lg:text-left">
            <div className="space-y-6">
              <h1 className="text-4xl font-extrabold tracking-tight sm:text-5xl md:text-6xl lg:text-6xl leading-[1.1]">
                Smart Financial <span className="text-primary bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/60">Calculators</span> for Everyone
              </h1>
              <p className="max-w-[600px] text-lg text-muted-foreground md:text-xl mx-auto lg:mx-0 leading-relaxed">
                Plan investments, loans, taxes, retirement, and wealth creation using powerful financial calculators designed for accurate results and smarter decisions.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4 sm:max-w-md mx-auto lg:mx-0 text-sm font-medium">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-primary" />
                <span>50+ Financial Calculators</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-primary" />
                <span>Accurate Formulas</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-primary" />
                <span>100% Free To Use</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-primary" />
                <span>No Registration Required</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link href="/calculators/sip-calculator" className={buttonVariants({ size: "lg", className: "group" })}>
                Start Calculating
                <ChevronRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link href="/calculators" className={buttonVariants({ variant: "outline", size: "lg" })}>
                Explore All Tools
              </Link>
            </div>
          </div>

          {/* Right Side: Interactive Preview */}
          <div className="relative mx-auto w-full max-w-md lg:max-w-lg perspective-1000">
            {/* Background glowing blob */}
            <div className="absolute -inset-1 rounded-2xl bg-gradient-to-tr from-primary to-primary/20 opacity-30 blur-2xl" />
            
            <div className="relative bg-card border border-border shadow-2xl rounded-2xl p-6 lg:p-8 transform-gpu transition-transform hover:-translate-y-1 hover:shadow-primary/10">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-semibold text-lg flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  Live Preview: SIP Calculator
                </h3>
              </div>
              
              <div className="space-y-6">
                <SliderInput
                  label="Monthly SIP"
                  value={monthlyInvestment}
                  min={500}
                  max={100000}
                  step={500}
                  onChange={setMonthlyInvestment}
                  symbol="₹"
                />
                <div className="grid grid-cols-2 gap-4">
                  <SliderInput
                    label="Returns"
                    value={expectedReturnRate}
                    min={1}
                    max={30}
                    step={1}
                    onChange={setExpectedReturnRate}
                    suffix="%"
                  />
                  <SliderInput
                    label="Years"
                    value={timePeriodYears}
                    min={1}
                    max={40}
                    step={1}
                    onChange={setTimePeriodYears}
                    suffix="Y"
                  />
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-border flex items-end justify-between">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Expected Wealth</p>
                  <p className="text-3xl font-bold text-primary tracking-tight">
                    ₹{result.totalValue.toLocaleString('en-IN')}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground mb-1">Invested: ₹{result.investedAmount.toLocaleString('en-IN')}</p>
                  <p className="text-xs text-green-500 font-medium">Gain: +₹{result.estimatedReturns.toLocaleString('en-IN')}</p>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
