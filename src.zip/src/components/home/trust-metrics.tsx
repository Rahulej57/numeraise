import { Calculator, Activity, ShieldCheck, Clock } from "lucide-react";

export function TrustMetrics() {
  return (
    <section className="w-full py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center divide-x-0 md:divide-x divide-border">
          
          <div className="flex flex-col items-center p-4 hover:scale-105 transition-transform duration-300">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-4">
              <Calculator className="w-6 h-6" />
            </div>
            <h3 className="text-4xl font-extrabold tracking-tight mb-2">50+</h3>
            <p className="text-sm text-muted-foreground font-medium uppercase tracking-wider">Financial Calculators</p>
          </div>

          <div className="flex flex-col items-center p-4 hover:scale-105 transition-transform duration-300">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-4">
              <Activity className="w-6 h-6" />
            </div>
            <h3 className="text-4xl font-extrabold tracking-tight mb-2">100K+</h3>
            <p className="text-sm text-muted-foreground font-medium uppercase tracking-wider">Calculations Performed</p>
          </div>

          <div className="flex flex-col items-center p-4 hover:scale-105 transition-transform duration-300">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-4">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-4xl font-extrabold tracking-tight mb-2">100%</h3>
            <p className="text-sm text-muted-foreground font-medium uppercase tracking-wider">Free Tools</p>
          </div>

          <div className="flex flex-col items-center p-4 hover:scale-105 transition-transform duration-300">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-4">
              <Clock className="w-6 h-6" />
            </div>
            <h3 className="text-4xl font-extrabold tracking-tight mb-2">24/7</h3>
            <p className="text-sm text-muted-foreground font-medium uppercase tracking-wider">Available Online</p>
          </div>

        </div>
      </div>
    </section>
  );
}
