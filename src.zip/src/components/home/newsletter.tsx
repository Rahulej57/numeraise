"use client";

import { useState } from "react";
import { Mail, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function Newsletter() {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    
    // Simulate API call
    setTimeout(() => {
      setSubscribed(true);
      setEmail("");
    }, 500);
  };

  return (
    <section className="w-full py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto bg-primary/5 dark:bg-primary/10 border border-primary/20 rounded-3xl p-8 md:p-12 lg:p-16 text-center">
          <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <Mail className="w-8 h-8 text-primary" />
          </div>
          
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">
            Get Weekly Financial Insights
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join 50,000+ subscribers receiving our best investment tips, tax updates, and wealth building guides straight to their inbox.
          </p>

          <div className="flex flex-wrap justify-center gap-4 md:gap-8 mb-10 text-sm font-medium">
            <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-primary" /> Investment Tips</div>
            <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-primary" /> Tax Updates</div>
            <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-primary" /> Wealth Building</div>
          </div>

          {subscribed ? (
            <div className="bg-green-500/10 border border-green-500/20 text-green-600 dark:text-green-400 p-4 rounded-xl max-w-md mx-auto animate-in fade-in zoom-in duration-300">
              <p className="font-semibold flex items-center justify-center gap-2">
                <CheckCircle2 className="w-5 h-5" />
                Successfully subscribed!
              </p>
              <p className="text-sm mt-1">Check your inbox for the welcome email.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <Input 
                type="email" 
                placeholder="Enter your email address..." 
                className="h-12 text-base bg-background"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <Button type="submit" size="lg" className="h-12 px-8">
                Subscribe
              </Button>
            </form>
          )}
          
          <p className="text-xs text-muted-foreground mt-6">
            We respect your privacy. No spam, unsubscribe at any time.
          </p>
        </div>
      </div>
    </section>
  );
}
