import Link from "next/link";
import { TrendingUp, Landmark, Calculator, ShieldCheck } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const POPULAR = [
  {
    title: "SIP Calculator",
    description: "Calculate Systematic Investment Plan returns over time.",
    icon: <TrendingUp className="h-6 w-6 text-primary" />,
    href: "/calculators/sip-calculator",
    badge: "Most Popular",
    badgeVariant: "default" as const,
    usage: "15K+ users this week",
    time: "1 min",
  },
  {
    title: "Home Loan Calculator",
    description: "Plan your home loan EMI and amortization schedule.",
    icon: <Landmark className="h-6 w-6 text-primary" />,
    href: "/calculators/home-loan-calculator",
    badge: "Trending",
    badgeVariant: "secondary" as const,
    usage: "8K+ users this week",
    time: "2 mins",
  },
  {
    title: "Lumpsum Calculator",
    description: "Calculate compounding growth for bulk investments.",
    icon: <TrendingUp className="h-6 w-6 text-primary" />,
    href: "/calculators/lumpsum-calculator",
    usage: "12K+ users this week",
    time: "1 min",
  },
  {
    title: "EMI Calculator",
    description: "Calculate installments for car and personal loans.",
    icon: <Landmark className="h-6 w-6 text-primary" />,
    href: "/calculators/emi-calculator",
    usage: "10K+ users this week",
    time: "1 min",
  },
  {
    title: "FD Calculator",
    description: "Calculate Fixed Deposit maturity with quarterly compounding.",
    icon: <Calculator className="h-6 w-6 text-primary" />,
    href: "/calculators/fd-calculator",
    usage: "6K+ users this week",
    time: "1 min",
  },
  {
    title: "Income Tax Calculator",
    description: "Calculate your tax liability under the new regime.",
    icon: <Calculator className="h-6 w-6 text-primary" />,
    href: "/calculators/income-tax-calculator",
    badge: "Updated",
    badgeVariant: "outline" as const,
    usage: "25K+ users this week",
    time: "3 mins",
  },
];

export function PopularCalculators() {
  return (
    <section className="w-full py-16">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between mb-12 gap-4">
          <div>
            <h2 className="text-3xl font-bold tracking-tight mb-2">Most Used Calculators</h2>
            <p className="text-muted-foreground text-lg">Join thousands of users making smarter financial decisions.</p>
          </div>
          <Link href="/calculators" className="text-primary hover:underline font-medium whitespace-nowrap">
            View All Calculators &rarr;
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {POPULAR.map((calc) => (
            <Link href={calc.href} key={calc.title} className="group">
              <Card className="h-full flex flex-col hover:border-primary/50 transition-colors">
                <CardHeader className="flex-1">
                  <div className="flex justify-between items-start mb-4">
                    <div className="p-3 bg-muted rounded-xl group-hover:bg-primary/10 transition-colors">
                      {calc.icon}
                    </div>
                    {calc.badge && (
                      <Badge variant={calc.badgeVariant}>{calc.badge}</Badge>
                    )}
                  </div>
                  <CardTitle className="text-xl mb-2 group-hover:text-primary transition-colors">
                    {calc.title}
                  </CardTitle>
                  <CardDescription className="text-base line-clamp-2">
                    {calc.description}
                  </CardDescription>
                </CardHeader>
                <CardFooter className="border-t pt-4 text-xs text-muted-foreground flex justify-between">
                  <span>{calc.usage}</span>
                  <span className="font-medium text-foreground">{calc.time} calculation</span>
                </CardFooter>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
