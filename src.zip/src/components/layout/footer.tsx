import Link from "next/link";

export function Footer() {
  return (
    <footer className="border-t py-6 md:py-0">
      <div className="container mx-auto px-4 flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
        <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
          &copy; {new Date().getFullYear()} FinCalcPro. All rights reserved.
        </p>
        <div className="flex gap-4 flex-wrap justify-center md:justify-end">
          <Link href="/about" className="text-sm font-medium text-muted-foreground hover:underline underline-offset-4">About Us</Link>
          <Link href="/contact" className="text-sm font-medium text-muted-foreground hover:underline underline-offset-4">Contact</Link>
          <Link href="/privacy" className="text-sm font-medium text-muted-foreground hover:underline underline-offset-4">Privacy</Link>
          <Link href="/terms" className="text-sm font-medium text-muted-foreground hover:underline underline-offset-4">Terms</Link>
          <Link href="/disclaimer" className="text-sm font-medium text-muted-foreground hover:underline underline-offset-4">Disclaimer</Link>
        </div>
      </div>
    </footer>
  );
}
