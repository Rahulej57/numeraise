import Link from "next/link";
import { buttonVariants } from "@/components/ui/button";

export function Navbar() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 flex h-16 items-center justify-between">
        <div className="flex gap-6 md:gap-10">
          <Link href="/" className="flex items-center space-x-2">
            <span className="inline-block font-bold text-xl text-primary">FinCalc<span className="text-foreground">Pro</span></span>
          </Link>
          <nav className="hidden md:flex gap-6">
            <Link href="/calculators/investment" className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground">
              Investments
            </Link>
            <Link href="/calculators/loan" className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground">
              Loans
            </Link>
            <Link href="/calculators/tax" className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground">
              Tax
            </Link>
            <Link href="/blog" className="flex items-center text-sm font-medium text-muted-foreground hover:text-foreground">
              Learn
            </Link>
          </nav>
        </div>
        <div className="flex flex-1 items-center justify-end space-x-4">
          <nav className="flex items-center space-x-2">
            <Link href="/auth/login" className={buttonVariants({ variant: "ghost", size: "sm" })}>
              Login
            </Link>
            <Link href="/auth/register" className={buttonVariants({ size: "sm" })}>
              Sign Up
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
