"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ChevronRight, Home } from "lucide-react";
import React from "react";

export function Breadcrumbs() {
  const pathname = usePathname();
  
  if (pathname === "/") return null;

  const paths = pathname.split("/").filter((p) => p);

  return (
    <div className="bg-muted/30 border-b">
      <div className="container mx-auto px-4 py-3 flex items-center text-sm text-muted-foreground overflow-x-auto whitespace-nowrap hide-scrollbar">
        <Link href="/" className="flex items-center hover:text-primary transition-colors">
          <Home className="w-4 h-4" />
        </Link>
        {paths.map((path, index) => {
          const href = `/${paths.slice(0, index + 1).join("/")}`;
          const isLast = index === paths.length - 1;
          const formattedPath = path
            .split("-")
            .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
            .join(" ");

          return (
            <React.Fragment key={path}>
              <ChevronRight className="w-4 h-4 mx-2 flex-shrink-0" />
              {isLast ? (
                <span className="font-medium text-foreground truncate">{formattedPath}</span>
              ) : (
                <Link href={href} className="hover:text-primary transition-colors truncate">
                  {formattedPath}
                </Link>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}
