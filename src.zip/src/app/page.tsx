import { HeroSection } from "@/components/home/hero-section";
import { GlobalSearch } from "@/components/home/global-search";
import { TrustMetrics } from "@/components/home/trust-metrics";
import { RecentlyViewed } from "@/components/home/recently-viewed";
import { CategoryShowcase } from "@/components/home/category-showcase";
import { PopularCalculators } from "@/components/home/popular-calculators";
import { TrendingCalculators } from "@/components/home/trending-calculators";
import { FeaturedComparison } from "@/components/home/featured-comparison";
import { WhyChooseUs } from "@/components/home/why-choose-us";
import { FeaturedArticles } from "@/components/home/featured-articles";
import { GlossaryPreview } from "@/components/home/glossary-preview";
import { Newsletter } from "@/components/home/newsletter";

export const metadata = {
  title: "FinCalcPro | Smart Financial Calculators & Planning Tools",
  description: "Plan investments, loans, taxes, retirement, and wealth creation using our powerful suite of 50+ financial calculators designed for smarter decisions.",
};

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* 1. Hero Section & Search */}
      <HeroSection />
      <GlobalSearch />
      
      {/* 2. Trust Building */}
      <TrustMetrics />
      
      {/* 3. Personalization */}
      <RecentlyViewed />
      
      {/* 4. Core Calculator Discovery */}
      <CategoryShowcase />
      <TrendingCalculators />
      <PopularCalculators />
      
      {/* 5. SEO Comparison Assets */}
      <FeaturedComparison />
      
      {/* 6. Deep Platform Authority */}
      <WhyChooseUs />
      
      {/* 7. Educational Ecosystem */}
      <FeaturedArticles />
      <GlossaryPreview />
      
      {/* 8. Conversion/Lead Gen */}
      <Newsletter />
    </div>
  );
}
