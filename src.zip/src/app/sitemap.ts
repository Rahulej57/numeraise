import { MetadataRoute } from 'next';

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://fincalcpro.com';

  // In a real app, fetch dynamic routes from Prisma
  const calculators = [
    '/calculators/sip-calculator',
    '/calculators/emi-calculator',
    '/calculators/income-tax-calculator',
  ];

  const calculatorUrls = calculators.map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: 'weekly' as const,
    priority: 0.8,
  }));

  return [
    {
      url: baseUrl,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 1,
    },
    {
      url: `${baseUrl}/blog`,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 0.9,
    },
    ...calculatorUrls,
  ];
}
