export default function PrivacyPage() {
  return (
    <div className="container mx-auto px-4 py-16 max-w-4xl prose prose-neutral dark:prose-invert">
      <h1 className="text-4xl font-bold tracking-tight mb-8">Privacy Policy</h1>
      <p className="text-muted-foreground">Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</p>
      
      <h3>1. Information We Collect</h3>
      <p>We do not collect or store any financial data you enter into our calculators. All calculations are performed entirely within your browser (client-side) to ensure absolute privacy and security. Your sensitive financial figures never leave your device.</p>
      
      <h3>2. Analytics and Cookies</h3>
      <p>We use industry-standard analytics tools and Google AdSense to monetize and improve the platform. These third-party services may use cookies or similar tracking technologies to collect non-personally identifiable information about your usage, browser, and device.</p>
      
      <h3>3. Third-Party Services</h3>
      <p>Our website may contain links to third-party websites or services that are not owned or controlled by us. We assume no responsibility for the content, privacy policies, or practices of any third-party websites.</p>
      
      <h3>4. Changes to This Policy</h3>
      <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.</p>
    </div>
  );
}
