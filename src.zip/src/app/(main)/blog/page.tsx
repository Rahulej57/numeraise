export default function BlogPage() {
  return (
    <div className="container mx-auto px-4 py-24 max-w-3xl text-center">
      <h1 className="text-4xl font-bold tracking-tight mb-6">Financial Knowledge Base</h1>
      <p className="text-xl text-muted-foreground mb-8">
        We are building a comprehensive library of articles, tutorials, and guides to help you master personal finance. 
        Check back soon!
      </p>
      <div className="p-8 bg-muted rounded-lg border border-dashed text-muted-foreground">
        Stay tuned for expert financial insights.
      </div>
    </div>
  );
}
