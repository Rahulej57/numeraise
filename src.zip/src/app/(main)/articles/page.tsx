import { ComingSoon } from "@/components/ui/coming-soon";

export default function ArticlesPage() {
  return <ComingSoon title="Financial Learning Center" />;
}
