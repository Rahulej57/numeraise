import { ComingSoon } from "@/components/ui/coming-soon";

export default function ArticleSlugPage() {
  return <ComingSoon title="Educational Guide" />;
}
