export default function TermsPage() {
  return (
    <div className="container mx-auto px-4 py-16 max-w-4xl prose prose-neutral dark:prose-invert">
      <h1 className="text-4xl font-bold tracking-tight mb-8">Terms of Service</h1>
      <p className="text-muted-foreground">Last updated: {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</p>
      
      <h3>1. Accuracy of Information</h3>
      <p>The calculators and financial tools provided on this platform are for illustrative and educational purposes only. While we strive for absolute accuracy using industry-standard mathematical models, we do not guarantee the exactness of the results. The actual returns, EMIs, or tax liabilities may vary depending on real-time market conditions, specific institutional policies, and dynamic tax regulations.</p>
      
      <h3>2. No Financial Advice</h3>
      <p>The content and tools on this website do not constitute professional financial, investment, legal, or tax advice. Always consult with a certified financial advisor or tax professional before making any significant financial decisions based on the estimations provided by our platform.</p>
      
      <h3>3. Limitation of Liability</h3>
      <p>We shall not be liable for any direct, indirect, incidental, special, or consequential damages resulting from the use or inability to use our tools and information. Your use of the platform is strictly at your own risk.</p>
    </div>
  );
}
