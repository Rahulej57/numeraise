"use client";

import { useState, useMemo, useDeferredValue, useEffect } from "react";
import { calculateFD } from "@/lib/calculations/investment";
import { SliderInput } from "@/components/calculators/slider-input";
import { BreakdownChart } from "@/components/charts/breakdown-chart";
import { DataTable } from "@/components/calculators/data-table";
import { ResultActions } from "@/components/calculators/result-actions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CalculatorContent } from "@/components/calculators/calculator-content";
import { FAQAccordion, FAQ } from "@/components/calculators/faq-accordion";
import { RelatedCalculators } from "@/components/calculators/related-calculators";
import { RelatedArticles } from "@/components/calculators/related-articles";
import { StructuredData } from "@/components/seo/structured-data";

export default function LumpsumCalculatorPage() {
  const [principal, setPrincipal] = useState(100000);
  const [interestRate, setInterestRate] = useState(12);
  const [timePeriodYears, setTimePeriodYears] = useState(10);

  // Sync state with URL on mount for shareable links
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.has('amount')) setPrincipal(Number(params.get('amount')));
    if (params.has('rate')) setInterestRate(Number(params.get('rate')));
    if (params.has('years')) setTimePeriodYears(Number(params.get('years')));
  }, []);

  // Lumpsum is basically compound interest (annual compounding typically used for mutual funds)
  const result = useMemo(
    () => calculateFD(principal, interestRate, timePeriodYears, 1), 
    [principal, interestRate, timePeriodYears]
  );

  const pieData = useMemo(() => [
    { name: "Invested Amount", value: principal, color: "var(--chart-1)" },
    { name: "Est. Returns", value: result.estimatedReturns, color: "var(--chart-2)" },
  ], [principal, result.estimatedReturns]);

  const deferredPieData = useDeferredValue(pieData);

  const shareUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}${window.location.pathname}?amount=${principal}&rate=${interestRate}&years=${timePeriodYears}`
    : '';

  const copyPayload = `Lumpsum Calculation Results:
Investment Amount: ₹${principal.toLocaleString('en-IN')}
Time Period: ${timePeriodYears} Years
Expected Return: ${interestRate}%

Total Invested: ₹${result.investedAmount.toLocaleString('en-IN')}
Estimated Returns: ₹${result.estimatedReturns.toLocaleString('en-IN')}
Total Wealth Created: ₹${result.totalValue.toLocaleString('en-IN')}

Calculate your own: ${shareUrl}`;

  const tableColumns = [
    { header: "Year", accessorKey: "year" },
    { header: "Invested", accessorKey: "invested", isNumeric: true },
    { header: "Returns", accessorKey: "interest", isNumeric: true },
    { header: "Balance", accessorKey: "balance", isNumeric: true },
  ];

  const faqs: FAQ[] = [
    {
      question: "What is a Lumpsum Investment?",
      answer: "A lumpsum investment is a single, one-time bulk investment made into a mutual fund, stock, or other financial instrument, as opposed to investing smaller amounts periodically (which is called an SIP)."
    },
    {
      question: "Is Lumpsum better than SIP?",
      answer: "Lumpsum investments historically generate higher absolute returns over the very long term because the entire principal is subjected to compounding from Day 1. However, SIPs offer better risk mitigation by averaging out the cost of purchase during market volatility."
    },
    {
      question: "When is the best time to make a Lumpsum investment?",
      answer: "The ideal time to deploy lumpsum cash is during market corrections or crashes. Buying when the market is down allows you to acquire more units for the same amount of money, significantly boosting future returns."
    },
    {
      question: "Can I do both Lumpsum and SIP?",
      answer: "Absolutely! Many successful investors run regular monthly SIPs and use lumpsum investments to deploy annual bonuses or windfall gains into the same mutual fund folios during market dips."
    },
    {
      question: "How is Lumpsum calculated?",
      answer: "Lumpsum returns are calculated using the standard Compound Interest formula: A = P(1 + r/n)^(nt), where P is principal, r is the annual interest rate, and t is the time period in years."
    }
  ];

  const relatedCalcs = [
    { title: "SIP Calculator", description: "Calculate returns for systematic investments.", href: "/calculators/sip-calculator" },
    { title: "FD Calculator", description: "Calculate secure Fixed Deposit returns.", href: "/calculators/fd-calculator" },
    { title: "Retirement Calculator", description: "Plan your retirement corpus.", href: "/calculators/retirement-calculator" }
  ];

  const relatedGuides = [
    { title: "SIP vs Lumpsum: Which Strategy Wins?", href: "#" },
    { title: "How to Invest a Windfall (Bonus or Inheritance)", href: "#" },
    { title: "Understanding Compounding Frequency", href: "#" },
    { title: "Top 10 Mutual Funds for Lumpsum Investment", href: "#" }
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8 text-center md:text-left">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-2">Lumpsum Calculator</h1>
        <p className="text-muted-foreground text-lg">Calculate returns for one-time mutual fund investments.</p>
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5 space-y-6">
          <Card className="border-border shadow-sm">
            <CardContent className="p-6 space-y-8">
              <SliderInput
                label="Total Investment"
                value={principal}
                min={5000}
                max={10000000}
                step={5000}
                onChange={setPrincipal}
                symbol="₹"
              />
              <SliderInput
                label="Expected Return Rate (p.a)"
                value={interestRate}
                min={1}
                max={30}
                step={0.5}
                onChange={setInterestRate}
                suffix="%"
              />
              <SliderInput
                label="Time Period"
                value={timePeriodYears}
                min={1}
                max={40}
                step={1}
                onChange={setTimePeriodYears}
                suffix="Yr"
              />
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-7">
          <Card className="border-border shadow-sm h-full">
            <CardHeader className="pb-2">
              <CardTitle>Calculation Results</CardTitle>
              <CardDescription>Your wealth creation breakdown</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div className="p-4 rounded-lg bg-muted/50 border">
                  <p className="text-sm text-muted-foreground mb-1">Invested Amount</p>
                  <p className="text-xl font-semibold">₹{result.investedAmount.toLocaleString('en-IN')}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50 border">
                  <p className="text-sm text-muted-foreground mb-1">Est. Returns</p>
                  <p className="text-xl font-semibold text-green-600 dark:text-green-400">₹{result.estimatedReturns.toLocaleString('en-IN')}</p>
                </div>
                <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                  <p className="text-sm text-primary font-medium mb-1">Total Value</p>
                  <p className="text-2xl font-bold text-primary">₹{result.totalValue.toLocaleString('en-IN')}</p>
                </div>
              </div>
              <Tabs defaultValue="breakdown" className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-4">
                  <TabsTrigger value="breakdown">Breakdown</TabsTrigger>
                  <TabsTrigger value="table">Data Table</TabsTrigger>
                </TabsList>
                <TabsContent value="breakdown" className="mt-4">
                  <BreakdownChart data={deferredPieData} />
                </TabsContent>
                <TabsContent value="table" className="mt-4">
                  <DataTable columns={tableColumns} data={result.yearlyData} />
                </TabsContent>
              </Tabs>

              <ResultActions 
                shareUrl={shareUrl}
                copyPayload={copyPayload}
                csvData={result.yearlyData}
                csvFilename="lumpsum_calculation_results.csv"
              />
            </CardContent>
          </Card>
        </div>
      </div>
      <CalculatorContent>
        <h2>What is a Lumpsum Calculator?</h2>
        <p>A Lumpsum Calculator is an essential financial tool designed to estimate the future value of a one-time, bulk investment made today. Whether you have received an annual bonus, an inheritance, or proceeds from selling real estate, deploying a large sum of cash requires careful planning. This calculator helps you visualize how that single investment will grow over years or decades through the power of compounding.</p>
        
        <h2>How to Use the Lumpsum Calculator</h2>
        <p>To forecast your wealth creation, simply adjust the three sliders:</p>
        <ul>
          <li><strong>Total Investment:</strong> The one-time amount you are ready to invest today.</li>
          <li><strong>Expected Return Rate:</strong> Your realistic expectation of annual growth (e.g., 10-12% for equity mutual funds, 6-7% for debt funds).</li>
          <li><strong>Time Period:</strong> The number of years you plan to leave the money invested without touching it.</li>
        </ul>

        <h3>The Mathematical Formula for Lumpsum Returns</h3>
        <p>Lumpsum growth relies entirely on the universal formula for Compound Interest. The calculation engine uses:</p>
        <div className="p-4 bg-muted/50 rounded-lg border font-mono text-center text-lg my-6">
          A = P × (1 + r/n)<sup>nt</sup>
        </div>
        <ul>
          <li><strong>A:</strong> Total Future Value (Principal + Returns)</li>
          <li><strong>P:</strong> Principal Investment Amount</li>
          <li><strong>r:</strong> Annual Interest Rate (in decimal form)</li>
          <li><strong>n:</strong> Number of times interest is compounded per year (Usually 1 for mutual funds)</li>
          <li><strong>t:</strong> Total time period in years</li>
        </ul>

        <h3>Practical Example Scenario</h3>
        <p>Imagine you receive a performance bonus of ₹5,00,000 and decide to invest it in an index mutual fund instead of buying a car. You expect a conservative 12% annual return over a 15-year holding period.</p>
        <ul>
          <li><strong>Investment (P):</strong> ₹5,00,000</li>
          <li><strong>Annual Return (r):</strong> 12% (0.12)</li>
          <li><strong>Time (t):</strong> 15 Years</li>
        </ul>
        <p>Without adding another single rupee, the power of compounding will turn your initial ₹5 Lakhs into <strong>₹27,36,783</strong>. Your money generated over ₹22 Lakhs in pure profit simply by staying invested over time!</p>

        <h2>SIP vs Lumpsum: The Eternal Debate</h2>
        <p>A common question is whether to invest a large amount immediately (Lumpsum) or stagger it over several months (SIP). Mathematically, if the market is on a long-term upward trajectory, Lumpsum will almost always beat SIP because your entire capital starts earning returns from Day 1.</p>
        <p>However, Lumpsum carries higher <strong>timing risk</strong>. If you invest your entire capital the day before a 20% market crash, your portfolio immediately drops by 20%, and it may take years to recover. If you are extremely risk-averse, staggering a large windfall into 6-12 monthly SIPs (often via an STP - Systematic Transfer Plan) can provide psychological comfort during volatile markets.</p>

        <h2>Common Mistakes to Avoid</h2>
        <p><strong>Panic Selling:</strong> Because lumpsum portfolios expose a large amount of capital to market volatility at once, it is common for new investors to panic when their portfolio shows a temporary 10-15% loss. Do not check your lumpsum portfolio daily. Invest and forget.</p>
        <p><strong>Unrealistic Expectations:</strong> Do not expect a 25% CAGR simply because the market performed well last year. Always run your lumpsum calculations with conservative estimates (10-12% for equity, 6-7% for debt) to avoid disappointment when funding your financial goals.</p>
      </CalculatorContent>

      <FAQAccordion faqs={faqs} />
      <RelatedCalculators calculators={relatedCalcs} />
      <RelatedArticles articles={relatedGuides} />

      <StructuredData 
        type="Calculator" 
        data={{
          name: "Lumpsum Calculator",
          description: "Calculate the future value and estimated returns of a one-time bulk investment using the power of compounding."
        }} 
      />
      <StructuredData type="FAQ" data={{ faqs }} />
    </div>
  );
}
