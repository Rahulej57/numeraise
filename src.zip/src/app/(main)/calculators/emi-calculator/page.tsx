"use client";

import { useState, useMemo, useDeferredValue, useEffect } from "react";
import { calculateEMI } from "@/lib/calculations/loan";
import { SliderInput } from "@/components/calculators/slider-input";
import { BreakdownChart } from "@/components/charts/breakdown-chart";
import { DataTable } from "@/components/calculators/data-table";
import { ResultActions } from "@/components/calculators/result-actions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CalculatorContent } from "@/components/calculators/calculator-content";
import { FAQAccordion, FAQ } from "@/components/calculators/faq-accordion";
import { RelatedCalculators } from "@/components/calculators/related-calculators";
import { RelatedArticles } from "@/components/calculators/related-articles";
import { StructuredData } from "@/components/seo/structured-data";

export default function EMICalculatorPage() {
  const [principal, setPrincipal] = useState(500000);
  const [interestRate, setInterestRate] = useState(8.5);
  const [tenureYears, setTenureYears] = useState(5);

  // Sync state with URL on mount for shareable links
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.has('amount')) setPrincipal(Number(params.get('amount')));
    if (params.has('rate')) setInterestRate(Number(params.get('rate')));
    if (params.has('years')) setTenureYears(Number(params.get('years')));
  }, []);

  const result = useMemo(
    () => calculateEMI(principal, interestRate, tenureYears),
    [principal, interestRate, tenureYears]
  );

  const pieData = useMemo(() => [
    { name: "Principal Amount", value: principal, color: "var(--chart-1)" },
    { name: "Total Interest", value: result.totalInterest, color: "var(--chart-2)" },
  ], [principal, result.totalInterest]);

  const deferredPieData = useDeferredValue(pieData);

  const shareUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}${window.location.pathname}?amount=${principal}&rate=${interestRate}&years=${tenureYears}`
    : '';

  const copyPayload = `EMI Calculation Results:
Loan Amount: ₹${principal.toLocaleString('en-IN')}
Tenure: ${tenureYears} Years
Interest Rate: ${interestRate}%

Monthly EMI: ₹${result.emi.toLocaleString('en-IN')}
Total Interest: ₹${result.totalInterest.toLocaleString('en-IN')}
Total Payment: ₹${result.totalPayment.toLocaleString('en-IN')}

Calculate your own: ${shareUrl}`;

  const tableColumns = [
    { header: "Month", accessorKey: "month" },
    { header: "Principal", accessorKey: "principal", isNumeric: true },
    { header: "Interest", accessorKey: "interest", isNumeric: true },
    { header: "Balance", accessorKey: "balance", isNumeric: true },
  ];

  const faqs: FAQ[] = [
    {
      question: "What is an EMI?",
      answer: "Equated Monthly Installment (EMI) is a fixed payment amount made by a borrower to a lender at a specified date each calendar month. Equated monthly installments are used to pay off both interest and principal each month so that over a specified number of years, the loan is paid off in full."
    },
    {
      question: "How is EMI calculated mathematically?",
      answer: "EMI is calculated using the formula: P × r × (1 + r)^n / ((1 + r)^n - 1), where P is the Principal loan amount, r is the monthly interest rate, and n is the total number of monthly installments."
    },
    {
      question: "Does EMI change during the loan tenure?",
      answer: "If you have a fixed-rate loan, your EMI remains constant throughout the tenure. However, if you have a floating-rate loan, your EMI or loan tenure will change whenever the bank adjusts its benchmark interest rates."
    },
    {
      question: "What happens if I miss an EMI payment?",
      answer: "Missing an EMI payment will negatively impact your credit score (CIBIL score). Your bank will also charge a late payment penalty and potentially a bounce fee if the auto-debit fails."
    },
    {
      question: "How can I reduce my EMI burden?",
      answer: "You can reduce your EMI by making prepayments (part-payments) towards your principal amount, opting for a longer loan tenure (though this increases total interest paid), or transferring your loan balance to another bank offering a lower interest rate."
    }
  ];

  const relatedCalcs = [
    { title: "Home Loan Calculator", description: "Plan your real estate purchases.", href: "/calculators/home-loan-calculator" },
    { title: "SIP Calculator", description: "Calculate wealth generation through mutual funds.", href: "/calculators/sip-calculator" },
    { title: "Lumpsum Calculator", description: "Calculate returns for one-time investments.", href: "/calculators/lumpsum-calculator" }
  ];

  const relatedGuides = [
    { title: "Fixed vs Floating Interest Rates: Which is Better?", href: "#" },
    { title: "How Prepayments Can Save You Lakhs in Interest", href: "#" },
    { title: "Understanding Your CIBIL Score", href: "#" },
    { title: "Smart Ways to Manage Personal Loans", href: "#" }
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8 text-center md:text-left">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-2">EMI Calculator</h1>
        <p className="text-muted-foreground text-lg">Calculate your Equated Monthly Installment for any loan.</p>
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5 space-y-6">
          <Card className="border-border shadow-sm">
            <CardContent className="p-6 space-y-8">
              <SliderInput
                label="Loan Amount"
                value={principal}
                min={10000}
                max={10000000}
                step={10000}
                onChange={setPrincipal}
                symbol="₹"
              />
              <SliderInput
                label="Interest Rate (p.a)"
                value={interestRate}
                min={1}
                max={30}
                step={0.1}
                onChange={setInterestRate}
                suffix="%"
              />
              <SliderInput
                label="Loan Tenure"
                value={tenureYears}
                min={1}
                max={30}
                step={1}
                onChange={setTenureYears}
                suffix="Yr"
              />
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-7">
          <Card className="border-border shadow-sm h-full">
            <CardHeader className="pb-2">
              <CardTitle>Calculation Results</CardTitle>
              <CardDescription>Your loan repayment breakdown</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                  <p className="text-sm text-primary font-medium mb-1">Monthly EMI</p>
                  <p className="text-2xl font-bold text-primary">₹{result.emi.toLocaleString('en-IN')}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50 border">
                  <p className="text-sm text-muted-foreground mb-1">Principal</p>
                  <p className="text-xl font-semibold">₹{principal.toLocaleString('en-IN')}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50 border">
                  <p className="text-sm text-muted-foreground mb-1">Total Interest</p>
                  <p className="text-xl font-semibold text-orange-500">₹{result.totalInterest.toLocaleString('en-IN')}</p>
                </div>
              </div>
              <Tabs defaultValue="breakdown" className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-4">
                  <TabsTrigger value="breakdown">Breakdown</TabsTrigger>
                  <TabsTrigger value="table">Amortization</TabsTrigger>
                </TabsList>
                <TabsContent value="breakdown" className="mt-4">
                  <BreakdownChart data={deferredPieData} />
                </TabsContent>
                <TabsContent value="table" className="mt-4">
                  <DataTable columns={tableColumns} data={result.amortizationSchedule} />
                </TabsContent>
              </Tabs>

              <ResultActions 
                shareUrl={shareUrl}
                copyPayload={copyPayload}
                csvData={result.amortizationSchedule}
                csvFilename="emi_amortization_schedule.csv"
              />
            </CardContent>
          </Card>
        </div>
      </div>
      <CalculatorContent>
        <h2>What is an EMI Calculator?</h2>
        <p>An EMI (Equated Monthly Installment) Calculator is a financial utility tool that helps you calculate the fixed monthly amount you need to pay towards your loan repayment. Whether you are taking a personal loan, car loan, or education loan, understanding your exact monthly outflow is crucial for maintaining a healthy financial budget.</p>
        
        <h2>How Does the EMI Calculator Work?</h2>
        <p>Our EMI calculator takes three primary inputs to generate your amortization schedule:</p>
        <ul>
          <li><strong>Principal Amount (P):</strong> The total amount you wish to borrow from the bank.</li>
          <li><strong>Interest Rate (R):</strong> The annual percentage rate charged by the lender.</li>
          <li><strong>Loan Tenure (N):</strong> The duration over which you will repay the loan, usually expressed in years or months.</li>
        </ul>

        <h3>The Mathematical Formula for EMI</h3>
        <p>The calculation is based on the standard universal formula used by all global banks and financial institutions:</p>
        <div className="p-4 bg-muted/50 rounded-lg border font-mono text-center text-lg my-6">
          EMI = [P × R × (1+R)<sup>N</sup>] / [(1+R)<sup>N</sup>-1]
        </div>
        <p><em>Note: In this formula, the annual interest rate must be converted to a monthly rate (Annual Rate / 12 / 100), and the tenure must be calculated in total months.</em></p>

        <h3>Example EMI Calculation</h3>
        <p>Let's assume you take a personal loan of ₹5,00,000 for a tenure of 5 years at an interest rate of 10.5% per annum.</p>
        <ul>
          <li><strong>Principal:</strong> ₹5,00,000</li>
          <li><strong>Monthly Interest Rate:</strong> 10.5% / 12 / 100 = 0.00875</li>
          <li><strong>Total Months:</strong> 5 Years × 12 = 60 Months</li>
        </ul>
        <p>Plugging these into the formula results in an EMI of <strong>₹10,747</strong>. Over the 5-year period, you will pay a total interest of <strong>₹1,44,817</strong>, making your total repayment amount <strong>₹6,44,817</strong>.</p>

        <h2>The Anatomy of an EMI</h2>
        <p>Every EMI you pay consists of two distinct components:</p>
        <ol>
          <li><strong>Principal Repayment:</strong> The portion of the EMI that goes towards reducing your actual outstanding loan amount.</li>
          <li><strong>Interest Payment:</strong> The cost charged by the bank for borrowing the money.</li>
        </ol>
        <p>In the initial years of your loan, the interest component makes up the massive majority of your EMI. As the years pass and your principal reduces, the proportion of interest drops and the principal repayment becomes the larger component. You can visualize this clearly by checking the "Amortization Table" tab in our calculator above.</p>

        <h2>Common Mistakes When Taking a Loan</h2>
        <p><strong>Ignoring the total interest payout:</strong> Borrowers often stretch their loan tenure to the maximum limit just to get a lower, more comfortable EMI. While this helps monthly cash flow, it drastically increases the total interest paid to the bank over the life of the loan. Always aim for the shortest tenure you can comfortably afford.</p>
        <p><strong>Not accounting for processing fees:</strong> The EMI is just the repayment. Banks charge processing fees, document charges, and GST on those fees. Always ask for the actual APR (Annual Percentage Rate) to know the true cost of your loan.</p>
      </CalculatorContent>

      <FAQAccordion faqs={faqs} />
      <RelatedCalculators calculators={relatedCalcs} />
      <RelatedArticles articles={relatedGuides} />

      <StructuredData 
        type="Calculator" 
        data={{
          name: "EMI Calculator",
          description: "Calculate your Equated Monthly Installment for personal loans and car loans instantly. View detailed amortization schedules."
        }} 
      />
      <StructuredData type="FAQ" data={{ faqs }} />
    </div>
  );
}
