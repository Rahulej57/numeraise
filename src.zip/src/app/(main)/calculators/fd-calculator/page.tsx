"use client";

import { useState, useMemo, useDeferredValue, useEffect } from "react";
import { calculateFD } from "@/lib/calculations/investment";
import { SliderInput } from "@/components/calculators/slider-input";
import { BreakdownChart } from "@/components/charts/breakdown-chart";
import { DataTable } from "@/components/calculators/data-table";
import { ResultActions } from "@/components/calculators/result-actions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CalculatorContent } from "@/components/calculators/calculator-content";
import { FAQAccordion, FAQ } from "@/components/calculators/faq-accordion";
import { RelatedCalculators } from "@/components/calculators/related-calculators";
import { RelatedArticles } from "@/components/calculators/related-articles";
import { StructuredData } from "@/components/seo/structured-data";

export default function FDCalculatorPage() {
  const [principal, setPrincipal] = useState(100000);
  const [interestRate, setInterestRate] = useState(7.5);
  const [timePeriodYears, setTimePeriodYears] = useState(5);

  // Sync state with URL on mount for shareable links
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.has('amount')) setPrincipal(Number(params.get('amount')));
    if (params.has('rate')) setInterestRate(Number(params.get('rate')));
    if (params.has('years')) setTimePeriodYears(Number(params.get('years')));
  }, []);

  const result = useMemo(
    () => calculateFD(principal, interestRate, timePeriodYears, 4), // Quarterly compounding
    [principal, interestRate, timePeriodYears]
  );

  const pieData = useMemo(() => [
    { name: "Invested Amount", value: principal, color: "var(--chart-1)" },
    { name: "Est. Returns", value: result.estimatedReturns, color: "var(--chart-2)" },
  ], [principal, result.estimatedReturns]);

  const deferredPieData = useDeferredValue(pieData);

  const shareUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}${window.location.pathname}?amount=${principal}&rate=${interestRate}&years=${timePeriodYears}`
    : '';

  const copyPayload = `Fixed Deposit Calculation Results:
Investment Amount: ₹${principal.toLocaleString('en-IN')}
Time Period: ${timePeriodYears} Years
Interest Rate: ${interestRate}%

Total Invested: ₹${result.investedAmount.toLocaleString('en-IN')}
Estimated Returns: ₹${result.estimatedReturns.toLocaleString('en-IN')}
Total Maturity Value: ₹${result.totalValue.toLocaleString('en-IN')}

Calculate your own: ${shareUrl}`;

  const tableColumns = [
    { header: "Year", accessorKey: "year" },
    { header: "Invested", accessorKey: "invested", isNumeric: true },
    { header: "Interest Earned", accessorKey: "interest", isNumeric: true },
    { header: "Total Value", accessorKey: "balance", isNumeric: true },
  ];

  const faqs: FAQ[] = [
    {
      question: "What is a Fixed Deposit (FD)?",
      answer: "A Fixed Deposit (FD) is a secure financial instrument offered by banks and non-banking financial companies (NBFCs). It provides investors a higher rate of interest than a regular savings account, until a given maturity date."
    },
    {
      question: "Is FD safe to invest?",
      answer: "Yes, FDs are considered one of the safest investment options. In India, deposits up to ₹5 Lakhs per bank are insured by the DICGC (a subsidiary of RBI)."
    },
    {
      question: "How is FD interest calculated?",
      answer: "Most banks in India calculate FD interest using quarterly compounding. This means the interest generated in the first 3 months is added to your principal, and you earn interest on that combined amount for the next quarter."
    },
    {
      question: "Can I break my FD before maturity?",
      answer: "Yes, you can prematurely withdraw your FD. However, banks usually charge a penalty of 0.5% to 1% on the applicable interest rate for the period the deposit was actually held."
    },
    {
      question: "Is FD interest taxable?",
      answer: "Yes, interest earned on FDs is fully taxable according to your income tax slab. Banks will deduct TDS (Tax Deducted at Source) at 10% if your interest income exceeds ₹40,000 in a financial year (₹50,000 for senior citizens)."
    }
  ];

  const relatedCalcs = [
    { title: "Lumpsum Calculator", description: "Compare FD returns vs Mutual Funds.", href: "/calculators/lumpsum-calculator" },
    { title: "SIP Calculator", description: "Calculate monthly systematic investments.", href: "/calculators/sip-calculator" },
    { title: "Income Tax Calculator", description: "Calculate your tax liability on FD interest.", href: "/calculators/income-tax-calculator" }
  ];

  const relatedGuides = [
    { title: "FD vs Debt Mutual Funds: Which is Better?", href: "#" },
    { title: "How to Avoid TDS on Fixed Deposits (Form 15G/15H)", href: "#" },
    { title: "Best FD Interest Rates for Senior Citizens", href: "#" },
    { title: "Understanding Quarterly Compounding", href: "#" }
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8 text-center md:text-left">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-2">Fixed Deposit (FD) Calculator</h1>
        <p className="text-muted-foreground text-lg">Calculate the maturity amount and interest earned on your FD.</p>
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5 space-y-6">
          <Card className="border-border shadow-sm">
            <CardContent className="p-6 space-y-8">
              <SliderInput
                label="Total Investment"
                value={principal}
                min={10000}
                max={10000000}
                step={10000}
                onChange={setPrincipal}
                symbol="₹"
              />
              <SliderInput
                label="Interest Rate (p.a)"
                value={interestRate}
                min={1}
                max={15}
                step={0.1}
                onChange={setInterestRate}
                suffix="%"
              />
              <SliderInput
                label="Time Period"
                value={timePeriodYears}
                min={1}
                max={20}
                step={1}
                onChange={setTimePeriodYears}
                suffix="Yr"
              />
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-7">
          <Card className="border-border shadow-sm h-full">
            <CardHeader className="pb-2">
              <CardTitle>Calculation Results</CardTitle>
              <CardDescription>Your FD maturity breakdown</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div className="p-4 rounded-lg bg-muted/50 border">
                  <p className="text-sm text-muted-foreground mb-1">Invested Amount</p>
                  <p className="text-xl font-semibold">₹{result.investedAmount.toLocaleString('en-IN')}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50 border">
                  <p className="text-sm text-muted-foreground mb-1">Total Interest</p>
                  <p className="text-xl font-semibold text-green-600 dark:text-green-400">₹{result.estimatedReturns.toLocaleString('en-IN')}</p>
                </div>
                <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                  <p className="text-sm text-primary font-medium mb-1">Maturity Value</p>
                  <p className="text-2xl font-bold text-primary">₹{result.totalValue.toLocaleString('en-IN')}</p>
                </div>
              </div>
              <Tabs defaultValue="breakdown" className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-4">
                  <TabsTrigger value="breakdown">Breakdown</TabsTrigger>
                  <TabsTrigger value="table">Data Table</TabsTrigger>
                </TabsList>
                <TabsContent value="breakdown" className="mt-4">
                  <BreakdownChart data={deferredPieData} />
                </TabsContent>
                <TabsContent value="table" className="mt-4">
                  <DataTable columns={tableColumns} data={result.yearlyData} />
                </TabsContent>
              </Tabs>

              <ResultActions 
                shareUrl={shareUrl}
                copyPayload={copyPayload}
                csvData={result.yearlyData}
                csvFilename="fd_calculation_results.csv"
              />
            </CardContent>
          </Card>
        </div>
      </div>
      <CalculatorContent>
        <h2>What is a Fixed Deposit (FD) Calculator?</h2>
        <p>A Fixed Deposit (FD) Calculator is an automated financial tool that helps you compute the exact maturity value and interest earned on your secure bank deposits. By inputting your deposit amount, the bank's offered interest rate, and your desired holding period, the calculator eliminates the need for complex manual compounding calculations.</p>
        
        <h2>How Does the FD Calculator Work?</h2>
        <p>In India, the vast majority of banks (such as SBI, HDFC, ICICI) compound fixed deposit interest <strong>quarterly</strong>. This means every three months, the interest you have earned is added back into your principal, increasing the base on which the next quarter's interest is calculated.</p>

        <h3>The Mathematical Formula for FD</h3>
        <p>Because of this quarterly compounding, the FD calculator uses the standard Compound Interest formula, adjusted for quarterly intervals:</p>
        <div className="p-4 bg-muted/50 rounded-lg border font-mono text-center text-lg my-6">
          A = P × (1 + r/n)<sup>n×t</sup>
        </div>
        <ul>
          <li><strong>A:</strong> Maturity Amount (Principal + Total Interest)</li>
          <li><strong>P:</strong> Principal Deposit Amount</li>
          <li><strong>r:</strong> Annual Interest Rate (expressed in decimals, e.g., 7% = 0.07)</li>
          <li><strong>n:</strong> Compounding Frequency per year (n = 4 for Quarterly)</li>
          <li><strong>t:</strong> Total Tenure in Years</li>
        </ul>

        <h3>Practical Example Scenario</h3>
        <p>Let's say you want to park your emergency fund of ₹2,00,000 in a secure FD for 3 years, and your bank is offering an interest rate of 7.00% p.a.</p>
        <ul>
          <li><strong>Deposit (P):</strong> ₹2,00,000</li>
          <li><strong>Interest Rate (r):</strong> 7.00% (0.07)</li>
          <li><strong>Tenure (t):</strong> 3 Years</li>
          <li><strong>Compounding (n):</strong> 4 (Quarterly)</li>
        </ul>
        <p>By using the calculator, we determine that your total interest earned will be <strong>₹46,288</strong>. Therefore, your total maturity value after 3 years will be <strong>₹2,46,288</strong>.</p>

        <h2>Benefits of Fixed Deposits</h2>
        <p><strong>Capital Protection:</strong> FDs are completely insulated from stock market volatility. If you invest ₹1 Lakh, your principal is 100% safe, making it the perfect instrument for emergency funds and short-term goals.</p>
        <p><strong>Guaranteed Returns:</strong> Unlike mutual funds where returns fluctuate, you lock in the interest rate the moment you open the FD. You know exactly what your maturity amount will be on day one.</p>

        <h2>Common Mistakes to Avoid</h2>
        <p><strong>Ignoring Inflation and Taxes:</strong> FD returns are fully taxable based on your income bracket. If inflation is 6% and your post-tax FD return is 5%, you are actually losing purchasing power. Never put long-term wealth creation money purely into FDs.</p>
        <p><strong>Premature Withdrawal Penalties:</strong> If you break an FD before maturity, banks will typically reduce your applicable interest rate by 1%. If you are unsure when you need the money, it is better to open a sweep-in FD or a liquid mutual fund instead.</p>
      </CalculatorContent>

      <FAQAccordion faqs={faqs} />
      <RelatedCalculators calculators={relatedCalcs} />
      <RelatedArticles articles={relatedGuides} />

      <StructuredData 
        type="Calculator" 
        data={{
          name: "Fixed Deposit (FD) Calculator",
          description: "Calculate your Fixed Deposit maturity value and interest earned with quarterly compounding accuracy."
        }} 
      />
      <StructuredData type="FAQ" data={{ faqs }} />
    </div>
  );
}
