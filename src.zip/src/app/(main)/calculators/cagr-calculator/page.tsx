import { ComingSoon } from "@/components/ui/coming-soon";

export default function CagrCalculatorPage() {
  return <ComingSoon title="CAGR Calculator" />;
}
