import { ComingSoon } from "@/components/ui/coming-soon";

export default function HomeLoanPrepaymentPage() {
  return <ComingSoon title="Home Loan Prepayment Calculator" />;
}
