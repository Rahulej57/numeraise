import { ComingSoon } from "@/components/ui/coming-soon";

export default function RetirementCalculatorPage() {
  return <ComingSoon title="Retirement & FIRE Calculator" />;
}
