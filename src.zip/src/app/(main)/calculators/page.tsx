import Link from "next/link";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { TrendingUp, Landmark, Calculator, ShieldCheck } from "lucide-react";

export default function AllCalculatorsPage() {
  const categories = [
    { title: "Investment Calculators", desc: "SIP, Lumpsum, Mutual Funds, FD", icon: <TrendingUp className="h-8 w-8 text-primary" />, slug: "investment" },
    { title: "Loan Calculators", desc: "EMI, Home, Personal, Car", icon: <Landmark className="h-8 w-8 text-primary" />, slug: "loan" },
    { title: "Tax Calculators", desc: "Income Tax, GST, HRA", icon: <Calculator className="h-8 w-8 text-primary" />, slug: "tax" },
    { title: "Insurance Calculators", desc: "Life, Health, Term", icon: <ShieldCheck className="h-8 w-8 text-primary" />, slug: "insurance" },
  ];

  return (
    <div className="container mx-auto px-4 py-12 max-w-6xl">
      <div className="mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">All Calculators</h1>
        <p className="text-xl text-muted-foreground">Choose a category to find the perfect financial tool for your needs.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {categories.map((cat) => (
          <Card key={cat.slug} className="hover:border-primary/50 transition-colors group cursor-pointer">
            <Link href={`/calculators/${cat.slug}`}>
              <CardHeader>
                <div className="mb-4">{cat.icon}</div>
                <CardTitle className="group-hover:text-primary transition-colors">{cat.title}</CardTitle>
                <CardDescription>{cat.desc}</CardDescription>
              </CardHeader>
            </Link>
          </Card>
        ))}
      </div>
    </div>
  );
}
