"use client";

import { useState, useDeferredValue } from "react";
import { SliderInput } from "@/components/calculators/slider-input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BreakdownChart } from "@/components/charts/breakdown-chart";

export default function TermInsuranceCalculatorPage() {
  const [currentAge, setCurrentAge] = useState(30);
  const [retirementAge, setRetirementAge] = useState(60);
  const [annualIncome, setAnnualIncome] = useState(1200000);
  const [existingCover, setExistingCover] = useState(0);

  // Basic Rule of Thumb: Life Cover should be 10-15x of annual income, minus existing cover
  const yearsToRetire = retirementAge - currentAge;
  const recommendedCover = Math.max(0, (annualIncome * 15) - existingCover);
  
  // Approximate annual premium (purely illustrative, assuming standard healthy individual)
  // roughly ₹1000 per 10L of cover for a 30 year old, scaling up with age.
  const baseRatePerLakh = 100 + (currentAge - 20) * 5; 
  const annualPremium = Math.round((recommendedCover / 100000) * baseRatePerLakh);

  const pieData = [
    { name: "Existing Cover", value: existingCover, color: "var(--chart-2)" },
    { name: "Required Additional Cover", value: recommendedCover, color: "var(--chart-1)" },
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8 text-center md:text-left">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-2">Term Insurance Calculator</h1>
        <p className="text-muted-foreground text-lg">Calculate how much life cover your family needs.</p>
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5 space-y-6">
          <Card className="border-border shadow-sm">
            <CardContent className="p-6 space-y-8">
              <SliderInput
                label="Current Age"
                value={currentAge}
                min={18}
                max={60}
                step={1}
                onChange={setCurrentAge}
                suffix="Yr"
              />
              <SliderInput
                label="Expected Retirement Age"
                value={retirementAge}
                min={40}
                max={75}
                step={1}
                onChange={setRetirementAge}
                suffix="Yr"
              />
              <SliderInput
                label="Current Annual Income"
                value={annualIncome}
                min={300000}
                max={50000000}
                step={100000}
                onChange={setAnnualIncome}
                symbol="₹"
              />
              <SliderInput
                label="Existing Life Cover"
                value={existingCover}
                min={0}
                max={50000000}
                step={500000}
                onChange={setExistingCover}
                symbol="₹"
              />
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-7">
          <Card className="border-border shadow-sm h-full">
            <CardHeader className="pb-2">
              <CardTitle>Your Protection Plan</CardTitle>
              <CardDescription>Based on the standard 15x income replacement rule.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                  <p className="text-sm text-primary font-medium mb-1">Recommended Life Cover</p>
                  <p className="text-3xl font-bold text-primary">₹{recommendedCover.toLocaleString('en-IN')}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50 border flex flex-col justify-center">
                  <p className="text-sm text-muted-foreground mb-1">Est. Annual Premium</p>
                  <p className="text-2xl font-semibold">₹{annualPremium.toLocaleString('en-IN')}</p>
                  <p className="text-xs text-muted-foreground mt-1">*Illustrative purposes only</p>
                </div>
              </div>
              <div className="mt-8">
                <BreakdownChart data={pieData} />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
