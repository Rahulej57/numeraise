"use client";

import { useState, useMemo, useDeferredValue, useEffect } from "react";
import { calculateSIP } from "@/lib/calculations/investment";
import { SliderInput } from "@/components/calculators/slider-input";
import { BreakdownChart } from "@/components/charts/breakdown-chart";
import { GrowthChart } from "@/components/charts/growth-chart";
import { DataTable } from "@/components/calculators/data-table";
import { ResultActions } from "@/components/calculators/result-actions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CalculatorContent } from "@/components/calculators/calculator-content";
import { FAQAccordion, FAQ } from "@/components/calculators/faq-accordion";
import { RelatedCalculators } from "@/components/calculators/related-calculators";
import { RelatedArticles } from "@/components/calculators/related-articles";
import { StructuredData } from "@/components/seo/structured-data";

export default function SIPCalculatorPage() {
  const [monthlyInvestment, setMonthlyInvestment] = useState(5000);
  const [expectedReturnRate, setExpectedReturnRate] = useState(12);
  const [timePeriodYears, setTimePeriodYears] = useState(10);

  // Sync state with URL on mount for shareable links
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.has('amount')) setMonthlyInvestment(Number(params.get('amount')));
    if (params.has('rate')) setExpectedReturnRate(Number(params.get('rate')));
    if (params.has('years')) setTimePeriodYears(Number(params.get('years')));
  }, []);

  const result = useMemo(
    () => calculateSIP(monthlyInvestment, expectedReturnRate, timePeriodYears),
    [monthlyInvestment, expectedReturnRate, timePeriodYears]
  );

  const pieData = useMemo(() => [
    { name: "Invested Amount", value: result.investedAmount, color: "var(--chart-1)" },
    { name: "Est. Returns", value: result.estimatedReturns, color: "var(--chart-2)" },
  ], [result.investedAmount, result.estimatedReturns]);

  const areaData = useMemo(() => result.yearlyData.map((y) => ({
    name: `Year ${y.year}`,
    "Invested": y.invested,
    "Total Value": y.balance,
  })), [result.yearlyData]);

  const deferredPieData = useDeferredValue(pieData);
  const deferredAreaData = useDeferredValue(areaData);

  const shareUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}${window.location.pathname}?amount=${monthlyInvestment}&rate=${expectedReturnRate}&years=${timePeriodYears}`
    : '';

  const copyPayload = `SIP Calculation Results:
Monthly Investment: ₹${monthlyInvestment.toLocaleString('en-IN')}
Time Period: ${timePeriodYears} Years
Expected Return: ${expectedReturnRate}%

Total Invested: ₹${result.investedAmount.toLocaleString('en-IN')}
Estimated Returns: ₹${result.estimatedReturns.toLocaleString('en-IN')}
Total Wealth Created: ₹${result.totalValue.toLocaleString('en-IN')}

Calculate your own: ${shareUrl}`;

  const tableColumns = [
    { header: "Year", accessorKey: "year" },
    { header: "Invested", accessorKey: "invested", isNumeric: true },
    { header: "Returns", accessorKey: "interest", isNumeric: true },
    { header: "Balance", accessorKey: "balance", isNumeric: true },
  ];

  const faqs: FAQ[] = [
    {
      question: "How is SIP calculated?",
      answer: "SIP is calculated using the future value of an annuity formula. The formula takes your monthly investment, the expected annual return rate (divided by 12 for monthly), and the total number of months you plan to invest."
    },
    {
      question: "Can I stop my SIP anytime?",
      answer: "Yes, you can pause or stop your SIP at any time. There are no penalties for stopping an SIP, unlike traditional insurance endowment policies."
    },
    {
      question: "Is SIP better than Lumpsum?",
      answer: "SIP allows for Rupee Cost Averaging, meaning you buy more units when markets are down and fewer when they are high. This averages out your cost over time and reduces market timing risk compared to Lumpsum."
    },
    {
      question: "What happens if I miss an SIP installment?",
      answer: "If you miss an installment due to insufficient bank balance, the mutual fund company does not penalize you. However, your bank might charge a bounce fee for the failed auto-debit."
    },
    {
      question: "Can SIP returns be guaranteed?",
      answer: "No, mutual fund SIP returns are linked to the market (equity or debt) and are subject to market risks. They are not guaranteed like a Bank Fixed Deposit (FD)."
    }
  ];

  const relatedCalcs = [
    { title: "Lumpsum Calculator", description: "Calculate returns for one-time investments.", href: "/calculators/lumpsum-calculator" },
    { title: "FD Calculator", description: "Calculate secure Fixed Deposit returns.", href: "/calculators/fd-calculator" },
    { title: "Home Loan Calculator", description: "Plan your real estate purchases.", href: "/calculators/home-loan-calculator" }
  ];

  const relatedGuides = [
    { title: "SIP vs Mutual Funds: What's the Difference?", href: "#" },
    { title: "The Power of Compounding Explained", href: "#" },
    { title: "How to Choose the Best Mutual Fund", href: "#" },
    { title: "Step-by-Step Retirement Planning", href: "#" }
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8 text-center md:text-left">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-2">SIP Calculator</h1>
        <p className="text-muted-foreground text-lg">Calculate the future value of your Systematic Investment Plan.</p>
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5 space-y-6">
          <Card className="border-border shadow-sm">
            <CardContent className="p-6 space-y-8">
              <SliderInput
                label="Monthly Investment"
                value={monthlyInvestment}
                min={500}
                max={1000000}
                step={500}
                onChange={setMonthlyInvestment}
                symbol="₹"
              />
              <SliderInput
                label="Expected Return Rate (p.a)"
                value={expectedReturnRate}
                min={1}
                max={30}
                step={0.5}
                onChange={setExpectedReturnRate}
                suffix="%"
              />
              <SliderInput
                label="Time Period"
                value={timePeriodYears}
                min={1}
                max={40}
                step={1}
                onChange={setTimePeriodYears}
                suffix="Yr"
              />
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-7">
          <Card className="border-border shadow-sm h-full">
            <CardHeader className="pb-2">
              <CardTitle>Calculation Results</CardTitle>
              <CardDescription>Your projected wealth creation</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div className="p-4 rounded-lg bg-muted/50 border">
                  <p className="text-sm text-muted-foreground mb-1">Invested Amount</p>
                  <p className="text-xl font-semibold">₹{result.investedAmount.toLocaleString('en-IN')}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50 border">
                  <p className="text-sm text-muted-foreground mb-1">Est. Returns</p>
                  <p className="text-xl font-semibold text-green-600 dark:text-green-400">₹{result.estimatedReturns.toLocaleString('en-IN')}</p>
                </div>
                <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                  <p className="text-sm text-primary font-medium mb-1">Total Value</p>
                  <p className="text-2xl font-bold text-primary">₹{result.totalValue.toLocaleString('en-IN')}</p>
                </div>
              </div>

              <Tabs defaultValue="growth" className="w-full">
                <TabsList className="grid w-full grid-cols-3 mb-4">
                  <TabsTrigger value="growth">Growth</TabsTrigger>
                  <TabsTrigger value="breakdown">Breakdown</TabsTrigger>
                  <TabsTrigger value="table">Data</TabsTrigger>
                </TabsList>
                <TabsContent value="growth" className="mt-4">
                  <GrowthChart 
                    data={deferredAreaData} 
                    xAxisKey="name" 
                    areas={[
                      { key: "Total Value", color: "hsl(var(--primary))", name: "Total Value" },
                      { key: "Invested", color: "hsl(var(--chart-3))", name: "Amount Invested" }
                    ]} 
                  />
                </TabsContent>
                <TabsContent value="breakdown" className="mt-4">
                  <BreakdownChart data={deferredPieData} />
                </TabsContent>
                <TabsContent value="table" className="mt-4">
                  <DataTable columns={tableColumns} data={result.yearlyData} />
                </TabsContent>
              </Tabs>

              <ResultActions 
                shareUrl={shareUrl}
                copyPayload={copyPayload}
                csvData={result.yearlyData}
                csvFilename="sip_calculation_results.csv"
              />
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Massive Content Section for SEO */}
      <CalculatorContent>
        <h2>What is a Systematic Investment Plan (SIP)?</h2>
        <p>A Systematic Investment Plan (SIP) is a highly disciplined financial strategy that allows you to invest a fixed amount of money at regular intervals—typically monthly—into mutual funds or stocks. Instead of attempting to time the market with a massive one-time lumpsum investment, SIP allows you to participate in wealth creation steadily over time.</p>
        <p>By investing a fixed amount regularly regardless of market conditions, you naturally buy more units when the market is down and fewer units when the market is up. This phenomenon is known as <strong>Rupee Cost Averaging</strong>.</p>

        <h2>How Does the SIP Calculator Work?</h2>
        <p>The FinCalcPro SIP Calculator estimates the future value of your monthly investments by leveraging the mathematical power of compounding. It plots your wealth creation journey over years or decades, visually showing you the difference between your principal investment and your estimated capital gains.</p>

        <h3>The SIP Mathematical Formula</h3>
        <p>The core engine behind this calculator relies on the Future Value of an Annuity formula. It is expressed as:</p>
        <div className="p-4 bg-muted/50 rounded-lg border font-mono text-center text-lg my-6">
          FV = P × [((1 + r)<sup>n</sup> - 1) / r] × (1 + r)
        </div>
        <ul>
          <li><strong>FV</strong>: Future Value of your investment (Total Wealth)</li>
          <li><strong>P</strong>: Periodic investment amount (Monthly SIP)</li>
          <li><strong>r</strong>: Monthly rate of return (Annual Return Rate / 12 / 100)</li>
          <li><strong>n</strong>: Total number of contributions (Years × 12)</li>
        </ul>

        <h3>Practical Example Calculation</h3>
        <p>Let's assume you want to start a monthly SIP of ₹10,000 for 15 years, and you expect a realistic equity return of 12% per annum.</p>
        <ul>
          <li><strong>Monthly Investment (P):</strong> ₹10,000</li>
          <li><strong>Annual Return:</strong> 12% (r = 0.01 per month)</li>
          <li><strong>Tenure (n):</strong> 15 Years (180 months)</li>
        </ul>
        <p>If you plug these variables into our calculator, the engine will reveal that your total invested amount over 15 years will be <strong>₹18,00,000</strong>. However, because of compounding, the estimated returns generated will be <strong>₹32,45,760</strong>, bringing your final Future Value to an impressive <strong>₹50,45,760</strong>.</p>

        <h2>Major Benefits of SIP Investing</h2>
        <ol>
          <li><strong>Disciplined Saving:</strong> Auto-debits force you to save before you spend, building a robust financial habit.</li>
          <li><strong>Rupee Cost Averaging:</strong> You completely eliminate the stress of "timing the market" because you buy at all market levels automatically.</li>
          <li><strong>The Eighth Wonder (Compounding):</strong> The longer you stay invested, the more your returns start generating their own returns.</li>
          <li><strong>Flexibility:</strong> You can start with as little as ₹500, pause the SIP anytime, or withdraw funds (subject to exit loads and lock-in periods like ELSS).</li>
        </ol>

        <h2>Common Mistakes to Avoid</h2>
        <p>Many novice investors make critical errors that destroy their wealth creation potential. The most common mistake is <strong>stopping the SIP during a market crash</strong>. Market crashes are actually when your SIP acquires the most units at massive discounts. Stopping during a crash defeats the entire purpose of Rupee Cost Averaging.</p>
        <p>Another frequent mistake is choosing an unrealistic expected return rate in the calculator. While Indian equities have historically delivered 12-14% over the long term, expecting 20%+ consistently is a recipe for missed goals. Always plan conservatively.</p>
      </CalculatorContent>

      <FAQAccordion faqs={faqs} />
      <RelatedCalculators calculators={relatedCalcs} />
      <RelatedArticles articles={relatedGuides} />

      <StructuredData 
        type="Calculator" 
        data={{
          name: "SIP Calculator",
          description: "Calculate the future value of your Systematic Investment Plan with detailed charts and amortization tables."
        }} 
      />
      <StructuredData type="FAQ" data={{ faqs }} />
    </div>
  );
}
