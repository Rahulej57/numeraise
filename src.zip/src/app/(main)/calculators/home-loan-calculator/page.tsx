"use client";

import { useState, useMemo, useDeferredValue, useEffect } from "react";
import { calculateEMI } from "@/lib/calculations/loan";
import { SliderInput } from "@/components/calculators/slider-input";
import { BreakdownChart } from "@/components/charts/breakdown-chart";
import { DataTable } from "@/components/calculators/data-table";
import { ResultActions } from "@/components/calculators/result-actions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CalculatorContent } from "@/components/calculators/calculator-content";
import { FAQAccordion, FAQ } from "@/components/calculators/faq-accordion";
import { RelatedCalculators } from "@/components/calculators/related-calculators";
import { RelatedArticles } from "@/components/calculators/related-articles";
import { StructuredData } from "@/components/seo/structured-data";

export default function HomeLoanCalculatorPage() {
  const [principal, setPrincipal] = useState(5000000);
  const [interestRate, setInterestRate] = useState(8.5);
  const [tenureYears, setTenureYears] = useState(20);

  // Sync state with URL on mount for shareable links
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.has('amount')) setPrincipal(Number(params.get('amount')));
    if (params.has('rate')) setInterestRate(Number(params.get('rate')));
    if (params.has('years')) setTenureYears(Number(params.get('years')));
  }, []);

  const result = useMemo(
    () => calculateEMI(principal, interestRate, tenureYears),
    [principal, interestRate, tenureYears]
  );

  const pieData = useMemo(() => [
    { name: "Principal Amount", value: principal, color: "var(--chart-1)" },
    { name: "Total Interest", value: result.totalInterest, color: "var(--chart-2)" },
  ], [principal, result.totalInterest]);

  const deferredPieData = useDeferredValue(pieData);

  const shareUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}${window.location.pathname}?amount=${principal}&rate=${interestRate}&years=${tenureYears}`
    : '';

  const copyPayload = `Home Loan Calculation Results:
Loan Amount: ₹${principal.toLocaleString('en-IN')}
Tenure: ${tenureYears} Years
Interest Rate: ${interestRate}%

Monthly EMI: ₹${result.emi.toLocaleString('en-IN')}
Total Interest: ₹${result.totalInterest.toLocaleString('en-IN')}
Total Payment: ₹${result.totalPayment.toLocaleString('en-IN')}

Calculate your own: ${shareUrl}`;

  const tableColumns = [
    { header: "Month", accessorKey: "month" },
    { header: "Principal", accessorKey: "principal", isNumeric: true },
    { header: "Interest", accessorKey: "interest", isNumeric: true },
    { header: "Balance", accessorKey: "balance", isNumeric: true },
  ];

  const faqs: FAQ[] = [
    {
      question: "What is a Home Loan EMI?",
      answer: "A Home Loan EMI is the monthly payment you make to the bank to repay your housing loan. It consists of both principal repayment and interest charges. In the early years of a 20-year loan, the majority of your EMI goes entirely towards interest."
    },
    {
      question: "How can I reduce my Home Loan interest?",
      answer: "The most effective way to reduce home loan interest is by making regular part-prepayments. Even paying just one extra EMI per year, or increasing your EMI by 5% annually, can shave years off your tenure and save lakhs in interest."
    },
    {
      question: "Are there tax benefits on Home Loans in India?",
      answer: "Yes. Under Section 80C, you can claim up to ₹1.5 Lakhs on the Principal repayment. Under Section 24(b), you can claim up to ₹2 Lakhs on the Interest paid for a self-occupied property."
    },
    {
      question: "Should I choose a Fixed or Floating rate?",
      answer: "Almost all home loans in India are floating rate loans, meaning the interest rate fluctuates based on the RBI Repo Rate. Fixed-rate loans are rare and usually come at a much higher premium."
    },
    {
      question: "Does the Home Loan Calculator include property tax and insurance?",
      answer: "No, this calculator only computes your principal and interest obligations to the bank. You should budget separately for property taxes, home insurance, and maintenance costs."
    }
  ];

  const relatedCalcs = [
    { title: "EMI Calculator", description: "Calculate car and personal loan EMIs.", href: "/calculators/emi-calculator" },
    { title: "SIP Calculator", description: "Invest the money you save from loan prepayments.", href: "/calculators/sip-calculator" },
    { title: "FD Calculator", description: "Calculate returns on secure deposits.", href: "/calculators/fd-calculator" }
  ];

  const relatedGuides = [
    { title: "The Ultimate Guide to Prepaying Your Home Loan", href: "#" },
    { title: "Home Loan Tax Benefits Explained (Sec 80C & 24b)", href: "#" },
    { title: "Floating vs Fixed Rates: Which is Better?", href: "#" },
    { title: "Hidden Charges in Home Loans You Must Know", href: "#" }
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8 text-center md:text-left">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-2">Home Loan Calculator</h1>
        <p className="text-muted-foreground text-lg">Calculate your Home Loan EMI, interest, and payment schedule.</p>
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5 space-y-6">
          <Card className="border-border shadow-sm">
            <CardContent className="p-6 space-y-8">
              <SliderInput
                label="Home Loan Amount"
                value={principal}
                min={500000}
                max={50000000}
                step={100000}
                onChange={setPrincipal}
                symbol="₹"
              />
              <SliderInput
                label="Interest Rate (p.a)"
                value={interestRate}
                min={5}
                max={15}
                step={0.1}
                onChange={setInterestRate}
                suffix="%"
              />
              <SliderInput
                label="Loan Tenure"
                value={tenureYears}
                min={1}
                max={30}
                step={1}
                onChange={setTenureYears}
                suffix="Yr"
              />
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-7">
          <Card className="border-border shadow-sm h-full">
            <CardHeader className="pb-2">
              <CardTitle>Calculation Results</CardTitle>
              <CardDescription>Your home loan repayment breakdown</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                  <p className="text-sm text-primary font-medium mb-1">Monthly EMI</p>
                  <p className="text-2xl font-bold text-primary">₹{result.emi.toLocaleString('en-IN')}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50 border">
                  <p className="text-sm text-muted-foreground mb-1">Principal</p>
                  <p className="text-xl font-semibold">₹{principal.toLocaleString('en-IN')}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50 border">
                  <p className="text-sm text-muted-foreground mb-1">Total Interest</p>
                  <p className="text-xl font-semibold text-orange-500">₹{result.totalInterest.toLocaleString('en-IN')}</p>
                </div>
              </div>
              <Tabs defaultValue="breakdown" className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-4">
                  <TabsTrigger value="breakdown">Breakdown</TabsTrigger>
                  <TabsTrigger value="table">Amortization</TabsTrigger>
                </TabsList>
                <TabsContent value="breakdown" className="mt-4">
                  <BreakdownChart data={deferredPieData} />
                </TabsContent>
                <TabsContent value="table" className="mt-4">
                  <DataTable columns={tableColumns} data={result.amortizationSchedule} />
                </TabsContent>
              </Tabs>

              <ResultActions 
                shareUrl={shareUrl}
                copyPayload={copyPayload}
                csvData={result.amortizationSchedule}
                csvFilename="home_loan_amortization_schedule.csv"
              />
            </CardContent>
          </Card>
        </div>
      </div>
      <CalculatorContent>
        <h2>What is a Home Loan Calculator?</h2>
        <p>A Home Loan Calculator is a specialized financial tool designed specifically for long-tenure, high-value mortgages. It helps prospective homebuyers calculate their Equated Monthly Installment (EMI) and visualize exactly how much interest they will pay over the lifespan of a 15, 20, or 30-year loan.</p>
        <p>Because home loans involve massive amounts of money and very long timeframes, the total interest paid often exceeds the original cost of the house itself. This calculator helps you understand that dynamic before you sign the mortgage agreement.</p>
        
        <h2>How to Use the Home Loan Calculator</h2>
        <p>To generate your home loan amortization schedule, you need three key inputs:</p>
        <ul>
          <li><strong>Loan Amount:</strong> The principal amount sanctioned by the bank (excluding the down payment you pay out of pocket).</li>
          <li><strong>Interest Rate:</strong> The annual floating or fixed rate offered by your lender.</li>
          <li><strong>Loan Tenure:</strong> The total number of years you have to repay the loan (typically 15 to 20 years).</li>
        </ul>

        <h3>The Amortization Formula</h3>
        <p>Like standard EMIs, home loans use the reducing balance method. The formula is:</p>
        <div className="p-4 bg-muted/50 rounded-lg border font-mono text-center text-lg my-6">
          EMI = [P × R × (1+R)<sup>N</sup>] / [(1+R)<sup>N</sup>-1]
        </div>
        <p><em>Where P = Principal, R = Monthly Interest Rate, and N = Total months.</em></p>

        <h3>Example Home Loan Scenario</h3>
        <p>Consider a realistic scenario for a 2BHK apartment in a metro city:</p>
        <ul>
          <li><strong>Loan Amount:</strong> ₹50,00,000</li>
          <li><strong>Interest Rate:</strong> 8.5% p.a.</li>
          <li><strong>Tenure:</strong> 20 Years</li>
        </ul>
        <p>According to the calculation, your monthly EMI will be <strong>₹43,391</strong>. While the EMI might seem manageable, the total interest paid over 20 years will be a staggering <strong>₹54,13,879</strong>. This means you will repay the bank a total of <strong>₹1,04,13,879</strong> for a 50L loan!</p>

        <h2>The Secret to Saving Lakhs: Prepayment</h2>
        <p>The most important realization you can have when looking at a Home Loan Calculator is the power of part-prepayment. Because interest is charged on the outstanding principal every month, making a lump sum payment directly against the principal drastically reduces your future interest burden.</p>
        <p><strong>Pro Tip:</strong> By simply paying just one extra EMI per year (13 EMIs instead of 12), you can reduce a 20-year loan to roughly 16 years, saving you millions of rupees in interest. Use our detailed Amortization Data Table above to see exactly how your balance drops month by month.</p>
      </CalculatorContent>

      <FAQAccordion faqs={faqs} />
      <RelatedCalculators calculators={relatedCalcs} />
      <RelatedArticles articles={relatedGuides} />

      <StructuredData 
        type="Calculator" 
        data={{
          name: "Home Loan Calculator",
          description: "Calculate your home loan EMI and total interest payable. See the amortization schedule to plan your real estate purchase."
        }} 
      />
      <StructuredData type="FAQ" data={{ faqs }} />
    </div>
  );
}
