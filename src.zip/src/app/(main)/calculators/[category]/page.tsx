import Link from "next/link";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { notFound } from "next/navigation";

const categories = {
  investment: {
    title: "Investment Calculators",
    description: "Plan your wealth creation with our investment calculators.",
    calculators: [
      { name: "SIP Calculator", desc: "Calculate your Systematic Investment Plan returns.", slug: "sip-calculator" },
      { name: "Lumpsum Calculator", desc: "Calculate returns for one-time investments.", slug: "lumpsum-calculator" },
      { name: "FD Calculator", desc: "Calculate your Fixed Deposit maturity amount.", slug: "fd-calculator" },
    ]
  },
  loan: {
    title: "Loan Calculators",
    description: "Calculate your EMIs and plan your borrowing.",
    calculators: [
      { name: "EMI Calculator", desc: "Calculate your Equated Monthly Installment.", slug: "emi-calculator" },
      { name: "Home Loan Calculator", desc: "Plan your home loan schedule.", slug: "home-loan-calculator" },
    ]
  },
  tax: {
    title: "Tax Calculators",
    description: "Estimate your taxes and plan your savings.",
    calculators: [
      { name: "Income Tax Calculator", desc: "Calculate your income tax liability.", slug: "income-tax-calculator" },
      { name: "GST Calculator", desc: "Calculate Goods and Services Tax.", slug: "gst-calculator" },
    ]
  },
  insurance: {
    title: "Insurance Calculators",
    description: "Calculate your insurance needs and premiums.",
    calculators: [
      { name: "Life Insurance Calculator", desc: "Estimate how much life cover you need.", slug: "life-insurance-calculator" },
      { name: "Term Insurance Calculator", desc: "Calculate your term plan needs.", slug: "term-insurance-calculator" },
    ]
  }
};

export default async function CategoryPage({ params }: { params: Promise<{ category: string }> }) {
  const resolvedParams = await params;
  const categoryData = categories[resolvedParams.category as keyof typeof categories];

  if (!categoryData) {
    notFound();
  }

  return (
    <div className="container mx-auto px-4 py-12 max-w-6xl">
      <div className="mb-12">
        <h1 className="text-4xl font-bold tracking-tight mb-4">{categoryData.title}</h1>
        <p className="text-xl text-muted-foreground">{categoryData.description}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categoryData.calculators.map((calc) => (
          <Card key={calc.slug} className="hover:border-primary/50 transition-colors group cursor-pointer">
            <Link href={`/calculators/${calc.slug}`}>
              <CardHeader>
                <CardTitle className="group-hover:text-primary transition-colors">{calc.name}</CardTitle>
                <CardDescription>{calc.desc}</CardDescription>
              </CardHeader>
            </Link>
          </Card>
        ))}
      </div>
    </div>
  );
}

export function generateStaticParams() {
  return Object.keys(categories).map((category) => ({
    category,
  }));
}
