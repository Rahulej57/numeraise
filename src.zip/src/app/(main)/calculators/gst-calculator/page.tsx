"use client";

import { useState, useEffect } from "react";
import { SliderInput } from "@/components/calculators/slider-input";
import { ResultActions } from "@/components/calculators/result-actions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function GSTCalculatorPage() {
  const [amount, setAmount] = useState(10000);
  const [gstRate, setGstRate] = useState(18);
  const [mode, setMode] = useState<"exclusive" | "inclusive">("exclusive");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.has('amount')) setAmount(Number(params.get('amount')));
    if (params.has('rate')) setGstRate(Number(params.get('rate')));
    if (params.has('mode')) setMode(params.get('mode') as any);
  }, []);

  const gstAmount = mode === "exclusive" 
    ? (amount * gstRate) / 100 
    : amount - (amount * (100 / (100 + gstRate)));
    
  const netAmount = mode === "exclusive" 
    ? amount + gstAmount 
    : amount - gstAmount;
    
  const totalAmount = mode === "exclusive" ? netAmount : amount;
  const originalCost = mode === "exclusive" ? amount : netAmount;

  const shareUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}${window.location.pathname}?amount=${amount}&rate=${gstRate}&mode=${mode}`
    : '';

  const copyPayload = `GST Calculation (${mode === "exclusive" ? "Exclusive" : "Inclusive"}):
Original Cost: ₹${Math.round(originalCost).toLocaleString('en-IN')}
GST Rate: ${gstRate}%
GST Amount: ₹${Math.round(gstAmount).toLocaleString('en-IN')}

Total Price: ₹${Math.round(totalAmount).toLocaleString('en-IN')}

Calculate your own: ${shareUrl}`;

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8 text-center md:text-left">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-2">GST Calculator</h1>
        <p className="text-muted-foreground text-lg">Calculate Goods and Services Tax instantly.</p>
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5 space-y-6">
          <Card className="border-border shadow-sm">
            <CardContent className="p-6 space-y-8">
              <Tabs value={mode} onValueChange={(v) => setMode(v as any)} className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="exclusive">GST Exclusive</TabsTrigger>
                  <TabsTrigger value="inclusive">GST Inclusive</TabsTrigger>
                </TabsList>
              </Tabs>
              
              <SliderInput
                label={mode === "exclusive" ? "Original Cost" : "Total Price (inc. GST)"}
                value={amount}
                min={100}
                max={1000000}
                step={100}
                onChange={setAmount}
                symbol="₹"
              />
              
              <div className="space-y-4">
                <p className="text-base font-medium">GST Rate</p>
                <div className="flex flex-wrap gap-3">
                  {[5, 12, 18, 28].map((rate) => (
                    <button
                      key={rate}
                      onClick={() => setGstRate(rate)}
                      className={`px-4 py-2 rounded-md border text-sm font-medium transition-colors ${
                        gstRate === rate 
                          ? "bg-primary text-primary-foreground border-primary" 
                          : "bg-background text-foreground hover:bg-muted"
                      }`}
                    >
                      {rate}%
                    </button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-7">
          <Card className="border-border shadow-sm h-full">
            <CardHeader className="pb-2">
              <CardTitle>Calculation Results</CardTitle>
              <CardDescription>GST Breakdown</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div className="p-4 rounded-lg bg-muted/50 border">
                  <p className="text-sm text-muted-foreground mb-1">Original Cost</p>
                  <p className="text-xl font-semibold">₹{Math.round(originalCost).toLocaleString('en-IN')}</p>
                </div>
                <div className="p-4 rounded-lg bg-muted/50 border">
                  <p className="text-sm text-muted-foreground mb-1">GST Amount ({gstRate}%)</p>
                  <p className="text-xl font-semibold text-orange-500">₹{Math.round(gstAmount).toLocaleString('en-IN')}</p>
                </div>
                <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                  <p className="text-sm text-primary font-medium mb-1">Total Price</p>
                  <p className="text-2xl font-bold text-primary">₹{Math.round(totalAmount).toLocaleString('en-IN')}</p>
                </div>
              </div>
              
              <div className="mt-8 p-4 bg-muted rounded-lg border">
                <h3 className="font-medium mb-2">Detailed Breakdown</h3>
                <div className="flex justify-between py-2 border-b">
                  <span className="text-muted-foreground">Original Cost</span>
                  <span className="font-medium">₹{Math.round(originalCost).toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between py-2 border-b">
                  <span className="text-muted-foreground">CGST ({gstRate/2}%)</span>
                  <span className="font-medium">₹{Math.round(gstAmount/2).toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between py-2 border-b">
                  <span className="text-muted-foreground">SGST ({gstRate/2}%)</span>
                  <span className="font-medium">₹{Math.round(gstAmount/2).toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between py-2 mt-2 font-bold text-lg">
                  <span>Total Amount</span>
                  <span className="text-primary">₹{Math.round(totalAmount).toLocaleString('en-IN')}</span>
                </div>
              </div>

              <ResultActions 
                shareUrl={shareUrl}
                copyPayload={copyPayload}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
