import { ComingSoon } from "@/components/ui/coming-soon";

export default function CategorySlugPage() {
  return <ComingSoon title="Category Exploration" />;
}
