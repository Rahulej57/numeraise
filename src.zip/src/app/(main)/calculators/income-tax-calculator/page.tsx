"use client";

import { useState, useEffect } from "react";
import { SliderInput } from "@/components/calculators/slider-input";
import { ResultActions } from "@/components/calculators/result-actions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function IncomeTaxCalculatorPage() {
  const [salary, setSalary] = useState(1500000);
  const [exemptions, setExemptions] = useState(0);
  const [regime, setRegime] = useState<"new" | "old">("new");

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.has('salary')) setSalary(Number(params.get('salary')));
    if (params.has('exemptions')) setExemptions(Number(params.get('exemptions')));
    if (params.has('regime')) setRegime(params.get('regime') as any);
  }, []);

  // Simplified Indian Tax Calculation (Illustrative - 2024 brackets)
  const calculateTax = () => {
    let tax = 0;
    if (regime === "new") {
      // New Regime (No exemptions allowed, standard deduction 50k usually included in salary input for simplicity here)
      const taxable = Math.max(0, salary - 50000); // 50k standard deduction
      if (taxable <= 700000) return 0; // Rebate under 87A
      
      if (taxable > 300000) tax += Math.min(taxable - 300000, 300000) * 0.05;
      if (taxable > 600000) tax += Math.min(taxable - 600000, 300000) * 0.10;
      if (taxable > 900000) tax += Math.min(taxable - 900000, 300000) * 0.15;
      if (taxable > 1200000) tax += Math.min(taxable - 1200000, 300000) * 0.20;
      if (taxable > 1500000) tax += (taxable - 1500000) * 0.30;
    } else {
      // Old Regime
      const taxable = Math.max(0, salary - exemptions - 50000); // 50k standard deduction + custom exemptions (80C, HRA etc)
      if (taxable <= 500000) return 0; // Rebate
      
      if (taxable > 250000) tax += Math.min(taxable - 250000, 250000) * 0.05;
      if (taxable > 500000) tax += Math.min(taxable - 500000, 500000) * 0.20;
      if (taxable > 1000000) tax += (taxable - 1000000) * 0.30;
    }
    
    // Add 4% Health and Education Cess
    return Math.round(tax * 1.04);
  };

  const totalTax = calculateTax();
  const effectiveTaxRate = salary > 0 ? ((totalTax / salary) * 100).toFixed(1) : "0.0";
  const inHand = salary - totalTax;

  const shareUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}${window.location.pathname}?salary=${salary}&exemptions=${exemptions}&regime=${regime}`
    : '';

  const copyPayload = `Income Tax Calculation (${regime === "new" ? "New" : "Old"} Regime):
Gross Salary: ₹${salary.toLocaleString('en-IN')}
Deductions: ₹${exemptions.toLocaleString('en-IN')}

Total Tax: ₹${totalTax.toLocaleString('en-IN')}
Effective Tax Rate: ${effectiveTaxRate}%
In-Hand Salary: ₹${inHand.toLocaleString('en-IN')}

Calculate your own: ${shareUrl}`;

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8 text-center md:text-left">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-2">Income Tax Calculator</h1>
        <p className="text-muted-foreground text-lg">Estimate your tax liability under New vs Old regime.</p>
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5 space-y-6">
          <Card className="border-border shadow-sm">
            <CardContent className="p-6 space-y-8">
              <Tabs value={regime} onValueChange={(v) => setRegime(v as any)} className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="new">New Regime</TabsTrigger>
                  <TabsTrigger value="old">Old Regime</TabsTrigger>
                </TabsList>
              </Tabs>
              
              <SliderInput
                label="Gross Annual Salary"
                value={salary}
                min={300000}
                max={50000000}
                step={100000}
                onChange={setSalary}
                symbol="₹"
              />
              
              <div className={`transition-opacity ${regime === "new" ? "opacity-50 pointer-events-none" : "opacity-100"}`}>
                <SliderInput
                  label="Total Deductions (80C, HRA, etc.)"
                  value={regime === "new" ? 0 : exemptions}
                  min={0}
                  max={1500000}
                  step={10000}
                  onChange={setExemptions}
                  symbol="₹"
                />
                {regime === "new" && <p className="text-xs text-muted-foreground mt-2">Deductions are not applicable in the New Tax Regime (except standard deduction of 50k).</p>}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-7">
          <Card className="border-border shadow-sm h-full">
            <CardHeader className="pb-2">
              <CardTitle>Tax Summary ({regime === "new" ? "New" : "Old"} Regime)</CardTitle>
              <CardDescription>Your estimated tax liability for the financial year.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                <div className="p-4 rounded-lg bg-muted/50 border">
                  <p className="text-sm text-muted-foreground mb-1">Gross Salary</p>
                  <p className="text-xl font-semibold">₹{salary.toLocaleString('en-IN')}</p>
                </div>
                <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/20">
                  <p className="text-sm text-destructive font-medium mb-1">Total Tax</p>
                  <p className="text-2xl font-bold text-destructive">₹{totalTax.toLocaleString('en-IN')}</p>
                </div>
                <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
                  <p className="text-sm text-primary font-medium mb-1">In-Hand Salary</p>
                  <p className="text-2xl font-bold text-primary">₹{inHand.toLocaleString('en-IN')}</p>
                </div>
              </div>
              
              <div className="mt-8 p-4 bg-muted rounded-lg border">
                <h3 className="font-medium mb-2">Tax Breakdown</h3>
                <div className="flex justify-between py-2 border-b">
                  <span className="text-muted-foreground">Gross Income</span>
                  <span className="font-medium">₹{salary.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between py-2 border-b">
                  <span className="text-muted-foreground">Standard Deduction</span>
                  <span className="font-medium">- ₹50,000</span>
                </div>
                {regime === "old" && (
                  <div className="flex justify-between py-2 border-b">
                    <span className="text-muted-foreground">Other Deductions</span>
                    <span className="font-medium">- ₹{exemptions.toLocaleString('en-IN')}</span>
                  </div>
                )}
                <div className="flex justify-between py-2 border-b">
                  <span className="text-muted-foreground">Taxable Income</span>
                  <span className="font-medium">
                    ₹{Math.max(0, salary - 50000 - (regime === "old" ? exemptions : 0)).toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="flex justify-between py-2 mt-2 font-bold text-lg">
                  <span>Effective Tax Rate</span>
                  <span className="text-destructive">{effectiveTaxRate}%</span>
                </div>
              </div>
              
              <ResultActions 
                shareUrl={shareUrl}
                copyPayload={copyPayload}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
