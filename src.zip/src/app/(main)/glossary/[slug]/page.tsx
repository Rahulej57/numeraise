import { ComingSoon } from "@/components/ui/coming-soon";

export default function GlossarySlugPage() {
  return <ComingSoon title="Glossary Term Definition" />;
}
