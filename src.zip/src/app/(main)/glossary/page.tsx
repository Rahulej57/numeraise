import { ComingSoon } from "@/components/ui/coming-soon";

export default function GlossaryPage() {
  return <ComingSoon title="Financial Glossary" />;
}
