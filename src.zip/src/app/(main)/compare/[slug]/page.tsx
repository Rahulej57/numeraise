import { ComingSoon } from "@/components/ui/coming-soon";

export default function CompareSlugPage() {
  return <ComingSoon title="Scenario Comparison Engine" />;
}
